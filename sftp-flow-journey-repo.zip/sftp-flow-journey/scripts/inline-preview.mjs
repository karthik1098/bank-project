// Inlines the esbuild output into a single self-contained preview/preview.html.
import { readFileSync, writeFileSync, rmSync } from 'node:fs';

const js = readFileSync('preview/dist/app.js', 'utf8');
const css = readFileSync('preview/dist/app.css', 'utf8');
const page = readFileSync('preview/preview.css', 'utf8');
if (js.toLowerCase().includes('</script')) throw new Error('Bundle contains </script>; cannot inline safely.');

const html = `<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<title>SFTP File Journey</title>
<style>
${page}
${css}
</style>
</head>
<body>
<div id="root"></div>
<script>
${js}
</script>
</body>
</html>
`;
writeFileSync('preview/preview.html', html);
rmSync('preview/dist', { recursive: true, force: true });
console.log('Wrote preview/preview.html');
