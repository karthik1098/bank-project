import { useState } from 'react';
import { createRoot } from 'react-dom/client';
import SftpFlowJourney from '../src/SftpFlowJourney.jsx';

function Preview() {
  const [theme, setTheme] = useState(() => {
    try { return window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light'; } catch (e) { return 'light'; }
  });
  const [connection, setConnection] = useState('connected');
  const [clientName, setClientName] = useState('Acme Telecom');
  const dark = theme === 'dark';
  return (
    <div className={`pv ${dark ? 'pv-dark' : 'pv-light'}`}>
      <div className="pv-bar">
        <strong>Preview controls</strong>
        <label>Client name <input value={clientName} onChange={(e) => setClientName(e.target.value)} /></label>
        <button type="button" onClick={() => setTheme(dark ? 'light' : 'dark')}>{dark ? 'Switch to light mode' : 'Switch to dark mode'}</button>
        <button type="button" onClick={() => setConnection(connection === 'connected' ? 'unreachable' : 'connected')}>
          {connection === 'connected' ? 'Simulate client SFTP outage' : 'Restore client SFTP'}
        </button>
        <span className="pv-note">Sample data only. In iResolve this panel sits inside each client’s dashboard.</span>
      </div>
      <SftpFlowJourney clientName={clientName || '[Client name]'} theme={theme} connection={connection} hosts={{ dazstr: 'dazstr' }} />
    </div>
  );
}

createRoot(document.getElementById('root')).render(<Preview />);
