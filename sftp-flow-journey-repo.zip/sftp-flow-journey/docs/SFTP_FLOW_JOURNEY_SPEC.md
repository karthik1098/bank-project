# SFTP File Journey — spec for the iResolve SFTP Control Centre

**Goal:** In each client's dashboard, replace the current file-movement / connection-status block with a live, animated "file journey" panel. A non-technical user should understand what the SFTP module does for that client without reading any documentation. They should also be able to see where any given file is right now.

**Deliverables in this package**

| File | What it is |
|---|---|
| `src/SftpFlowJourney.jsx` | The React component (React 18/19, no other dependencies). Drop-in. |
| `src/SftpFlowJourney.css` | All styles, scoped under `.sfj`. Theme tokens at the top. |
| `preview/preview.html` | Standalone build of the component with sample data. Open it in a browser to see the target behaviour. |
| `docs/SFTP_FLOW_JOURNEY_SPEC.md` | This document. |

---

## 1. Instructions for Codex (implementation steps)

1. Copy `SftpFlowJourney.jsx` and `SftpFlowJourney.css` into the frontend, for example `src/modules/sftp-control-centre/components/`. Keep the CSS import at the top of the JSX file. If the project uses TypeScript, convert to `.tsx` and add types from §4 and §6, keeping the logic unchanged.
2. Find the existing per-client dashboard section that shows file movements / connection status. Replace that block with:
   ```jsx
   <SftpFlowJourney
     clientName={client.name}
     theme={isDarkMode ? 'dark' : 'light'}          // wire to iResolve's existing theme toggle
     connection={client.sftpReachable ? 'connected' : 'unreachable'}
     hosts={{
       clientSftp: client.sftpHost,                  // e.g. sftp.client.com
       dazstr: 'dazstr',
       readyFolder: client.readyFolderPath,
       archive: client.archivePath,
       artivaEfs: client.artivaEfsPath,
     }}
     events={events}                                 // from the endpoint in §6; omit to run the sample simulator
     flagBelow={78}                                  // quality-score threshold (confirm real value)
   />
   ```
3. Add the backend endpoint in §6 (Django) and a small polling hook (§6.4) that feeds `events`.
4. Replace the colour tokens at the top of `SftpFlowJourney.css` with iResolve's real light/dark values (§8.1). Change nothing else in the CSS for that.
5. Do **not** load Google Fonts or any CDN (HIPAA server, no external calls). The component inherits the app's font. The mono face falls back to the system monospace stack.
6. Verify against the acceptance criteria in §11.

Do not change: the stage model, the connector geometry, the "motion only where a file moves" rule, the demo script copy, or the accessibility behaviour, unless this spec is updated.

---

## 2. What the user sees

```
 CLIENT            │ CRM · iRESOLVE — fully automatic                      │ ARTIVA — separate program
                   │                    ┌──────────────┐                   │
 [Client] uploads  │      locked .pgp ─▶│ 3 PGP unlock │─▶ now readable    │
       │           │                    └──────────────┘        │          │
       ▼           │                                            ▼          │
 ┌────────────┐    │ ┌───────────────┐  readable files    ┌──────────────┐ │  ┌────────────┐
 │1 Client    │───▶│ │2 iResolve SFTP│──── go straight ──▶│4 Ready on    │─┼─▶│7 Artiva EFS│
 │  SFTP      │    │ │   (dazstr)    │                    │   dazstr     │ │  └────────────┘
 └────────────┘    │ └───────────────┘                    └──────────────┘ │
                   │                            copy ╱                ╲ copy │
                   │                    ┌──────────────┐    ┌──────────┐   │
                   │                    │5 Quality     │    │6 Archive │   │
                   │                    │  check/score │    │          │   │
                   │                    └──────────────┘    └──────────┘   │
```

From top to bottom the panel has:

1. **Header**
   - Client name.
   - A one-sentence plain-English status line, e.g. "All systems normal — 2 files on the way."
   - **Demo | Live** switch.
   - A **Play demo** button (in Demo mode).
   - Four stat tiles: Picked up, On the way, Flagged (still sent), Last movement.
2. **Flow stage**
   - Seven stages, the connectors between them, and file "tokens" that physically travel along the connectors.
   - Each token shows the file name with a padlock (locked/PGP), a document icon (readable) or a copy icon (side-branch copy).
   - A legend box.
3. **Live file movements**
   - The latest 8 movements, newest first.
   - Clicking a row opens that file's **journey**: every stage with its timestamp and the quality score.
4. **Stage guide**
   - For the selected stage it shows **What happens**, **Why it matters** and **If something's wrong**, with Previous/Next.
   - Clicking any stage on the flow selects it.

---

## 3. Stages and flow rules

| # | id | Title | Host line | Kind |
|---|---|---|---|---|
| 1 | `client` | Client SFTP | `hosts.clientSftp` | main |
| 2 | `dazstr` | iResolve SFTP | `host · dazstr` | main |
| 3 | `pgp` | PGP unlock | CRM private key | main, **only for encrypted files** |
| 4 | `ready` | Ready on dazstr | `hosts.readyFolder` | main; iResolve's hand-off point |
| 5 | `score` | Quality check | side branch · never blocks | **side branch** off `ready` |
| 6 | `archive` | Archive | `hosts.archive` | **side branch** off `ready` |
| 7 | `artiva` | Artiva EFS | `hosts.artivaEfs` | main; moved by a **separate Artiva program** |

**Rules**

- Encrypted file route: `client → dazstr → pgp → ready → artiva`.
- Readable file route: `client → dazstr → ready → artiva` (skips PGP via the straight "readable files go straight" line).
- `score` and `archive` are copies that branch off `ready`. They never block the main file. A low score is shown as "flagged for review, still delivered".
- `ready → artiva` crosses into the Artiva zone. It is drawn dashed with a hand-off marker because iResolve does not perform it.
- Everything is automatic. No step needs a person.

**Connectors** (stage coordinates, 1376×700 design space; tokens and arrows follow these exact paths):

| Segment | Path |
|---|---|
| `source>client` | `M125 112 L125 300` |
| `client>dazstr` | `M125 300 L450 300` |
| `dazstr>pgp` | `M450 300 C450 170 540 110 665 110` |
| `pgp>ready` | `M665 110 C790 110 880 180 880 300` |
| `dazstr>ready` | `M450 300 L880 300` |
| `ready>artiva` | `M880 300 L1265 300` (dashed) |
| `ready>score` | `M880 300 C780 320 720 380 710 520` (dashed) |
| `ready>archive` | `M880 300 C980 320 1040 380 1050 520` (dashed) |

The stage is drawn at a fixed 1376×700 and scaled to the container width with `transform: scale()` (ResizeObserver). Below about 900px wide it becomes small, which is acceptable because this is a desktop dashboard panel.

---

## 4. Component API

```ts
type Props = {
  clientName?: string;                         // default "[Client name]"
  hosts?: {
    clientSftp?: string; dazstr?: string; readyFolder?: string;
    archive?: string; artivaEfs?: string;
  };
  theme?: 'dark' | 'light';                    // default 'dark'
  connection?: 'connected' | 'unreachable';    // Client SFTP reachability
  events?: SftpFileEvent[];                    // live events (§6). Omit → sample simulator in Live mode
  defaultMode?: 'demo' | 'live';               // default: 'live' if events passed, else 'demo'
  flagBelow?: number;                          // default 78 — used when an event has no `flagged`
  className?: string;
};
```

Exports: `default SftpFlowJourney`, plus `STAGES`, `STAGE_ORDER`, `SEGMENTS`, `DEMO_STEPS` (useful for tests and for the backend team's stage mapping).

---

## 5. Modes

### 5.1 Demo (the "Play demo" walkthrough)

**Idle state:**
- The stage is static and covered by a soft overlay card. The card has a large **Play** button, the line "See how {client}'s files travel", a 1-sentence explanation, and an "or watch live activity" link.

**While playing:**
- **One step at a time:** each step moves one file one hop (or emits the two side-branch copies).
- **Spotlight:** the step's stage(s) are highlighted and all other stages dim to 30%.
- **Caption card:** shown bottom-left, with "STEP n OF 11", a progress bar, a title and one sentence.
- **Controls:** Pause/Resume, Next step, Restart; at the end, Replay and Watch live.
- **Stage guide:** the panel below follows the current stage.

| # | Spotlight | Event(s) emitted | Caption title | ms |
|---|---|---|---|---|
| 0 | — | — | Watch one file make the trip | 2400 |
| 1 | client | file 1 → client | The client drops a file | 3000 |
| 2 | dazstr | file 1 → dazstr | iResolve collects it | 3000 |
| 3 | pgp | file 1 → pgp | Locked? iResolve unlocks it | 3200 |
| 4 | ready | file 1 → ready | Ready for hand-off | 3000 |
| 5 | score, archive | file 1 → score (92), archive | Copies branch off — nothing waits | 3800 |
| 6 | artiva | file 1 → artiva | Artiva takes over | 3200 |
| 7 | client | file 2 → client | Now a file that isn't locked | 2600 |
| 8 | dazstr | file 2 → dazstr | Collected the same way | 2200 |
| 9 | ready | file 2 → ready (bypass) | It skips the unlock step | 3000 |
| 10 | score, archive, artiva | file 2 → score (85), archive, artiva | Same checks, same archive, same hand-off | 3600 |
| end | — | — | That's the whole journey | — |

- File 1 is `placements_1029.csv.pgp` (encrypted). File 2 is `payments_1029.txt` (readable).
- Full caption sentences are in `DEMO_STEPS` in the JSX.
- Starting or replaying the demo resets all counters.

### 5.2 Live

- **Source of events:** the component animates `events` from the backend.
- **First load:** events already present are applied **without animation**. This fills the counters, the log and the journeys.
- **After that:** each new event animates exactly one hop.
- **Without `events`:** a sample simulator runs instead, starting a new sample file every 3.6s and moving it one stage every 1.6s. It is for demos only.
- **Status line:**
  - Normally: "All systems normal — N files on the way. M flagged for review, still delivered."
  - When the client is unreachable (red): "We can't reach {client}'s server right now. iResolve keeps retrying by itself — nothing is lost."
  - When an error event arrives (red): "Attention needed at "{stage}": {message}".

---

## 6. Live data — event contract and backend

### 6.1 Event shape (what the component consumes)

```ts
type SftpFileEvent = {
  id: string | number;          // unique per event (used for de-duplication)
  fileId: string | number;      // stable id for one file across all its events
  fileName: string;             // as received, e.g. "placements_1029.csv.pgp"
  stage: 'client' | 'dazstr' | 'pgp' | 'ready' | 'score' | 'archive' | 'artiva';
  time: string;                 // ISO-8601, e.g. "2026-10-29T04:38:23+05:30"
  encrypted?: boolean;          // send on the first event of the file (true if PGP)
  score?: number;               // 0–100, on stage 'score'
  flagged?: boolean;            // on stage 'score'; if omitted, score < flagBelow
  status?: 'ok' | 'error';      // 'error' turns the stage red and shows `message`
  message?: string;             // optional plain-English override for the log line
};
```

**Example timeline for one encrypted file:**

```json
[
  {"id":101,"fileId":"f-88","fileName":"placements_1029.csv.pgp","stage":"client","time":"2026-10-29T04:38:17+05:30","encrypted":true},
  {"id":102,"fileId":"f-88","fileName":"placements_1029.csv.pgp","stage":"dazstr","time":"2026-10-29T04:38:20+05:30"},
  {"id":103,"fileId":"f-88","fileName":"placements_1029.csv.pgp","stage":"pgp","time":"2026-10-29T04:38:23+05:30"},
  {"id":104,"fileId":"f-88","fileName":"placements_1029.csv.pgp","stage":"ready","time":"2026-10-29T04:38:26+05:30"},
  {"id":105,"fileId":"f-88","fileName":"placements_1029.csv.pgp","stage":"score","time":"2026-10-29T04:38:29+05:30","score":92},
  {"id":106,"fileId":"f-88","fileName":"placements_1029.csv.pgp","stage":"archive","time":"2026-10-29T04:38:29+05:30"},
  {"id":107,"fileId":"f-88","fileName":"placements_1029.csv.pgp","stage":"artiva","time":"2026-10-29T04:41:02+05:30"}
]
```

**Error example** (decrypt failed):

```json
{"id":201,"fileId":"f-90","fileName":"recalls_1029.csv.pgp","stage":"pgp","time":"…","status":"error","message":"Couldn't unlock — key mismatch. Ask the client to resend."}
```

**Ordering rules:**
- Send events in time order.
- For each file, the main-path stages must appear in route order, so the component can draw the correct connector.
- If a stage is skipped, the stage still updates, but no token is animated (no matching connector).

### 6.2 Mapping iResolve SFTP steps → stages

| iResolve SFTP module step | `stage` |
|---|---|
| New file detected on the client's SFTP (listing/poll found it) | `client` |
| Download/copy to dazstr completed | `dazstr` |
| PGP decryption completed (only for `.pgp`/encrypted) | `pgp` |
| Readable file written to dazstr ready folder | `ready` |
| Validation & scoring job finished | `score` |
| Copy written to archive | `archive` |
| File seen on Artiva EFS / picked up by the Artiva program | `artiva` |

**Confirm (`artiva`):** can iResolve observe the `artiva` step? For example, the Artiva program removing the file from the ready folder, or the file appearing on EFS. If not, omit `artiva` events. The panel then shows files as "handed over" at `ready`, and the Artiva stage counts stay at 0.

### 6.3 Backend (Django, zero added infrastructure)

- **Storage:** if the SFTP module doesn't already log per-file steps, add a table:

  ```python
  class SftpFileEvent(models.Model):
      client = models.ForeignKey('clients.Client', on_delete=models.CASCADE, db_index=True)
      file_id = models.CharField(max_length=64, db_index=True)   # e.g. hash of client+path+mtime, or the transfer job id
      file_name = models.CharField(max_length=512)
      stage = models.CharField(max_length=16, choices=[(s, s) for s in
              ['client','dazstr','pgp','ready','score','archive','artiva']])
      occurred_at = models.DateTimeField(db_index=True)
      encrypted = models.BooleanField(null=True)
      score = models.PositiveSmallIntegerField(null=True)
      flagged = models.BooleanField(null=True)
      status = models.CharField(max_length=8, default='ok')       # 'ok' | 'error'
      message = models.CharField(max_length=300, blank=True)
      class Meta:
          indexes = [models.Index(fields=['client', 'occurred_at'])]
  ```

- **Writing events:** write one row at each step of the existing SFTP pipeline (Celery tasks or the transfer worker).
- **Endpoint:** `GET /api/sftp/clients/<client_id>/events?since=<event_id>&limit=200`
  - Without `since`, it returns today's events (or the last 200), oldest first.
  - With `since`, it returns only newer events.
  - The response is the event shape from §6.1 (`occurred_at` → `time`).
  - Guard it with the existing `require_module()` permission for the SFTP Control Centre.
- **Connection status:** also return `{ "connection": "connected" | "unreachable", "hosts": {...} }`. Use either `GET /api/sftp/clients/<id>/status` or a combined response.
- **Data protection:** do not send file contents or account data. File names and timestamps only.

### 6.4 Frontend polling (recommended over SSE behind IIS)

- **Poll** the endpoint every 5 seconds while the tab is visible, and append new events to `events`.
- **Why not SSE:** server-sent events through IIS/ARR need response buffering turned off, so polling is simpler.
- **Memory:** keep `events` to the last ~300. The component itself only keeps the latest 40 files and 8 log rows.

```jsx
function useSftpEvents(clientId) {
  const [events, setEvents] = useState([]);
  const lastId = useRef(null);
  useEffect(() => {
    let alive = true;
    const tick = async () => {
      if (document.hidden) return;
      const q = lastId.current ? `?since=${lastId.current}` : '';
      const res = await fetch(`/api/sftp/clients/${clientId}/events${q}`, { credentials: 'include' });
      if (!res.ok || !alive) return;
      const batch = await res.json();
      if (batch.length) {
        lastId.current = batch[batch.length - 1].id;
        setEvents((prev) => [...prev, ...batch].slice(-300));
      }
    };
    tick();
    const iv = setInterval(tick, 5000);
    return () => { alive = false; clearInterval(iv); };
  }, [clientId]);
  return events;
}
```

Always pass a stable array (append, don't rebuild from scratch). The component de-duplicates by `id`.

---

## 7. Motion spec — "movement means a file is there"

| Element | At rest | When it animates |
|---|---|---|
| Connector line | Thin line at 45% opacity (side branches and the Artiva link dashed) + one fixed arrowhead at 55% of its length | Only while a file token is on it: brighter line, flowing dashes (0.7s loop), a light pulse travelling along it, and 3 moving chevrons. The fixed arrowhead hides |
| File token | — | Appears at the start of the connector, travels it in **1.35s** (`cubic-bezier(.6,0,.4,1)`), fades out at the stage. Locked files show a padlock and the `.pgp` name; after PGP unlock the name drops `.pgp` and shows a document icon |
| Side-branch copy | — | Smaller dashed pill "copy → scoring" / "copy → archive" on the dashed branch connectors |
| Stage badge | Static icon | On arrival: a ring expands and fades (1.1s), a progress arc spins round the badge, and the icon's own animation runs for **1.9s** |
| Stage icons (Lucide, MIT) | Static | Server: activity lights blink. Shield: check mark redraws. Padlock: shackle swings open. Folder: check redraws. Gauge: needle sweeps. Archive: lid lifts. Database: layers pulse. Client building: windows light up (on pickup) |
| Status dot / LIVE badge | Static green | Pulses only in Live mode; red pulse when unreachable or error |
| Log rows | — | New row slides in |
| Demo spotlight | — | Non-active stages fade to 30% opacity / desaturate (0.4s) |

`prefers-reduced-motion: reduce` turns off all looping motion. File tokens jump straight to their destination and the information stays complete.

---

## 8. Visual design

### 8.1 Tokens (replace with iResolve's real values)

The palette below is a best guess at iResolve's "half-white light / warm dark" look. Change only these variables in `SftpFlowJourney.css`.

| Token | Warm dark | Warm light | Used for |
|---|---|---|---|
| `--sfj-bg` | `#1A1714` | `#F4F1EB` | panel background |
| `--sfj-stage` | `#1E1A16` | `#FAF8F4` | flow stage background (with dot grid `--sfj-grid`) |
| `--sfj-surf` / `--sfj-surf2` | `#26211C` / `#2F2923` | `#FFFFFF` / `#F2EDE5` | cards, buttons |
| `--sfj-line` | `#3E362E` | `#E0D8CC` | borders, zone dividers |
| `--sfj-tx` / `--sfj-mu` / `--sfj-fa` | `#F3EDE4` / `#B8AC9C` / `#A09484` | `#2A241E` / `#5F564C` / `#6F655A` | text: primary / secondary / tertiary |
| `--sfj-ok` / `--sfj-bad` | `#8CCB8F` / `#F07167` | `#2F7D3A` / `#C0392B` | status |
| `--sfj-primary` | = `--sfj-dazstr` | = `--sfj-dazstr` | buttons, kicker text; set to iResolve's brand accent |

**Stage accents** (each also has a `-rgb` triplet for glows):

| Stage | Dark | Light |
|---|---|---|
| client | `#7FB8E6` | `#2F6FAE` |
| dazstr | `#E8925E` | `#B4572A` |
| pgp | `#B9A3F0` | `#6A50C2` |
| ready | `#6FC7B4` | `#1C7F6F` |
| score | `#F2C14E` | `#8A5F09` |
| archive | `#E8A0BF` | `#A8467A` |
| artiva | `#8CCB8F` | `#3A7F45` |

All text colours meet WCAG AA (4.5:1) on their surface in both themes. Light-mode accents are darker for that reason.

### 8.2 Typography

- Inherits the app font.
- Sizes:
  - Title: 28/700.
  - Stage names: 14/600.
  - Body: 13.5–15.
  - Labels: 11/600, uppercase, letter-spacing .14em.
- Data (file names, hosts, times, scores) uses the monospace stack `--sfj-mono`.

### 8.3 Layout

- Panel padding 24, gaps 20.
- Stage: rounded 18, 1px border, 22px dot grid.
- Three zones are separated by dashed dividers at x=250 and x=1130: CLIENT, CRM · iRESOLVE (fully automatic), ARTIVA (separate program).
- Stage badges are 84px (dazstr hub 100px), with a 180px info card below each showing title, host, status and current file.
- The legend is fixed bottom-right of the stage. The demo caption sits bottom-left (560px).
- Bottom panels: a 1.3fr / 1fr grid (log | stage guide). It stacks below 960px.

---

## 9. Copy (plain English, `{client}` = client name)

Stage guide copy lives in `STAGES` in the JSX: `guideTitle`, `what`, `why`, `wrong`.

**To confirm with the SFTP module owner:** the **"If something's wrong"** lines describe the intended behaviour. Make them match what iResolve actually does:
- Does a failed PGP unlock stop the file and show on stage 3?
- Do flagged files really continue to Artiva?
- Is the archive copy the decrypted file or the original `.pgp`? If it's the original, move the archive branch to come off `dazstr` instead of `ready`.

Log line templates are in `messageFor()`. Override per event with `message`.

---

## 10. Accessibility

- Every stage is a real `<button>` with an `aria-label`: "Stage n: title. status. Show explanation."
- Log rows, guide dots and the mode switch are buttons with `aria-pressed` / `aria-label`.
- Every interactive control is at least 44px tall.
- The status line and the demo caption use `role="status"` / `aria-live="polite"`.
- Decorative SVG, arrows and tokens are `aria-hidden`.
- Focus rings are visible (2px, accent colour).
- Colour is never the only signal: errors show red **and** text, locked files show a padlock icon **and** `.pgp`, and copies use a dashed border **and** the word "copy".
- Reduced motion is supported (§7).

---

## 11. Acceptance criteria

- [ ] Panel renders in the client dashboard in place of the old file-movement block, in both iResolve themes, following the app's theme toggle.
- [ ] Demo: idle overlay with Play; Play runs the 11 steps in order with captions; Pause/Resume/Next/Restart/Replay work; only the active connector animates; non-active stages dim.
- [ ] Live with real events: first load shows counts and log without animation. Each new event animates exactly one hop on the correct connector:
  - encrypted files go via PGP;
  - readable files go straight from dazstr to ready;
  - copies go to score and archive.
- [ ] At rest (no file moving), nothing on the stage moves except the LIVE pulse.
- [ ] `connection="unreachable"`:
  - Client SFTP stage, its connector and the status line turn red.
  - The status line says files are safe and iResolve is retrying.
- [ ] An event with `status: 'error'` turns that stage red with its message and adds a red log row.
- [ ] Clicking a log row opens that file's journey with per-stage timestamps and the score. Back returns to the stage guide.
- [ ] Clicking a stage shows its What / Why / If something's wrong text.
- [ ] Works at 1280px+ without horizontal scroll; scales down smoothly; bottom panels stack under 960px.
- [ ] No network calls other than the iResolve events/status endpoint; no external fonts.
- [ ] `prefers-reduced-motion` honoured.

---

## 12. Open questions / placeholders

- **Real values:**
  - client SFTP host per client;
  - dazstr ready-folder path;
  - archive path;
  - Artiva EFS path.

  They currently show as `[client-sftp-host]`, `[ready-folder]`, `[archive-path]`, `[artiva-efs-path]`.
- **Real quality-score threshold:** `flagBelow` is a placeholder at 78.
- **Artiva step visibility:** whether iResolve can observe the `artiva` step (see §6.2).
- **Archive source:** whether the archive keeps the original encrypted file (changes the archive branch origin, §9).
- **Theme colours:** iResolve's real light/dark tokens (§8.1).
- **Outbound files:** results sent back to the client are not shown. They could be added later as a reverse lane.
