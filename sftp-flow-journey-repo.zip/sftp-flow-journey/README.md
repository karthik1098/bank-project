# SFTP File Journey (iResolve)

Animated, live "file journey" panel for the iResolve **SFTP Control Centre**. It replaces the per-client file-movement / connection-status block and shows each client's files moving through these stages:

1. Client SFTP
2. iResolve SFTP (dazstr)
3. PGP unlock (only for locked files)
4. Ready on dazstr
5. Artiva EFS

Two side branches (quality check & scoring, and archive) come off step 4. Motion only happens where a file actually is. A **Play demo** walkthrough explains the flow to non-technical users.

## What's here

```
src/
  SftpFlowJourney.jsx     React component (React 18/19, no other dependencies)
  SftpFlowJourney.css     Styles, scoped under .sfj; theme colour tokens at the top
docs/
  SFTP_FLOW_JOURNEY_SPEC.md   Full spec: integration steps, props, event contract,
                              Django endpoint + polling hook, motion, design tokens,
                              accessibility, acceptance criteria, open questions
preview/
  preview.html            Standalone build with sample data. Open in any browser.
  preview-entry.jsx       Source of the preview (wraps the component with test controls)
  preview.css             Preview page styles
package.json              Optional: rebuild the preview with esbuild
```

## See it

Open `preview/preview.html` in a browser. It works offline, from a single file. Use the preview controls to:

- press **Play demo**;
- switch to **Live** (sample simulator);
- toggle light/dark;
- simulate a client SFTP outage.

## Use it in iResolve

Follow **§1 of `docs/SFTP_FLOW_JOURNEY_SPEC.md`**. In short:

```jsx
import SftpFlowJourney from './SftpFlowJourney';

<SftpFlowJourney
  clientName={client.name}
  theme={isDarkMode ? 'dark' : 'light'}
  connection={client.sftpReachable ? 'connected' : 'unreachable'}
  hosts={{ clientSftp: client.sftpHost, dazstr: 'dazstr', readyFolder, archive, artivaEfs }}
  events={events}   // from GET /api/sftp/clients/<id>/events (see spec §6); omit to run the sample simulator
/>
```

## Rebuild the preview (optional)

```bash
npm install
npm run build:preview   # writes preview/preview.html
```

## Before going live

Confirm the items in spec §12:

- real host and folder paths;
- the score threshold (`flagBelow`, placeholder 78);
- whether iResolve can observe the Artiva EFS step;
- whether the archive keeps the original encrypted file;
- iResolve's real light/dark colour tokens.
