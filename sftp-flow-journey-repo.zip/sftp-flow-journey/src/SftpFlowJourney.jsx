/**
 * SftpFlowJourney — live, animated "file journey" panel for the iResolve SFTP Control Centre.
 *
 * Shows, for ONE client, how files travel:
 *   Client SFTP → iResolve SFTP (dazstr) → [PGP unlock, only for .pgp files] → Ready on dazstr → Artiva EFS
 *   with two non-blocking side branches off "Ready on dazstr": Quality check (scored) and Archive.
 *   The last hop (dazstr → Artiva EFS) is done by a separate Artiva program, not iResolve.
 *
 * Modes
 *   - "demo": a scripted walkthrough (Play / Pause / Next / Replay) that follows one locked file, then one readable file.
 *   - "live": animates real events passed in via the `events` prop. If `events` is not passed, a sample simulator runs.
 *
 * Motion rule: lines, arrows and icons only animate where a file is actually moving or has just arrived.
 * No dependencies other than React 18. Styles live in SftpFlowJourney.css (all classes prefixed `sfj-`).
 * See SFTP_FLOW_JOURNEY_SPEC.md for the full spec, event contract and integration steps.
 */
import { useCallback, useEffect, useLayoutEffect, useReducer, useRef, useState } from 'react';
import './SftpFlowJourney.css';

/* ------------------------------------------------------------------ */
/* Constants                                                           */
/* ------------------------------------------------------------------ */

const STAGE_W = 1376; // design coordinate system of the flow stage (px)
const STAGE_H = 700;
const HOP_MS = 1350; // how long a file token takes to travel one connector
const BUSY_MS = 1900; // how long a stage icon stays animated after a file arrives
const SIM_STEP_MS = 1600; // sample simulator: delay between stages for one file
const SIM_SPAWN_MS = 3600; // sample simulator: a new file every N ms
const LOG_MAX = 8;
const FILE_MAX = 40;

/** Stage ids, in the order used by the guide and the file journey. */
export const STAGE_ORDER = ['client', 'dazstr', 'pgp', 'ready', 'score', 'archive', 'artiva'];
const MAIN_STAGES = ['client', 'dazstr', 'pgp', 'ready', 'artiva'];
const COPY_STAGES = ['score', 'archive'];

/** Stage model: position (badge centre on the stage), labels and plain-English guide copy. `{client}` is replaced with the client name. */
export const STAGES = {
  client: {
    x: 125, y: 300, title: 'Client SFTP', journey: 'Found on client SFTP',
    guideTitle: 'Client SFTP — the client’s drop box',
    what: '{client} drops new files on their own secure server. iResolve checks it on a schedule and collects anything new by itself.',
    why: 'Nobody has to log in, download or forward files by hand — pickup runs around the clock.',
    wrong: 'If this stage turns red, the client’s server isn’t answering. iResolve keeps retrying on its own; files wait safely on the client’s side.',
  },
  dazstr: {
    x: 450, y: 300, hub: true, title: 'iResolve SFTP', journey: 'Landed on dazstr',
    guideTitle: 'iResolve SFTP (dazstr) — our secure front door',
    what: 'Each file is copied onto dazstr, CRM’s own secure SFTP server run by iResolve. From here on, the file is inside CRM.',
    why: 'The client’s server is only touched to collect files. Everything else happens on our side.',
    wrong: 'Every arrival is logged with a time, so if a file seems missing you can see whether it ever reached CRM.',
  },
  pgp: {
    x: 665, y: 110, title: 'PGP unlock', journey: 'PGP lock removed',
    guideTitle: 'PGP unlock — opening locked files',
    what: 'Some clients lock files with PGP, a digital padlock only CRM’s key can open. iResolve spots locked files (names ending in .pgp) and unlocks them. Readable files skip this step.',
    why: 'Account data stays scrambled while it travels between companies.',
    wrong: 'If a locked file can’t be opened, it shows here so the team can ask {client} to resend it.',
  },
  ready: {
    x: 880, y: 300, title: 'Ready on dazstr', journey: 'Ready on dazstr',
    guideTitle: 'Ready on dazstr — where iResolve hands over',
    what: 'The readable file sits in dazstr’s ready folder. iResolve’s delivery work ends here.',
    why: 'One clear hand-off point: everything up to here is iResolve; moving it into Artiva is done by a separate Artiva program.',
    wrong: 'If files pile up here and don’t reach Artiva EFS, the issue is on the Artiva program’s side.',
  },
  score: {
    x: 710, y: 520, title: 'Quality check', journey: 'Quality checked',
    guideTitle: 'Quality check — scoring every file',
    what: 'Alongside delivery, iResolve reads a copy of the file, checks its layout and fields, and gives it a quality score out of 100.',
    why: 'Data problems are spotted early. The check never holds a file back — it carries on either way.',
    wrong: 'Low-scoring files are flagged here for someone to review, but they are still delivered.',
  },
  archive: {
    x: 1050, y: 520, title: 'Archive', journey: 'Archived',
    guideTitle: 'Archive — the permanent record',
    what: 'As soon as a file is on dazstr, a copy is saved to the archive.',
    why: 'There is always a record of exactly what {client} sent, and when.',
    wrong: 'If a file is ever lost or changed further down the line, the archived copy is still there.',
  },
  artiva: {
    x: 1265, y: 300, title: 'Artiva EFS', journey: 'In Artiva EFS',
    guideTitle: 'Artiva EFS — where the work begins',
    what: 'A separate Artiva program collects the file from dazstr and places it on Artiva EFS, where it is loaded into the collection system.',
    why: 'This is where the accounts in the file actually start being worked.',
    wrong: 'This step isn’t run by iResolve — questions about it go to the Artiva team.',
  },
};

/** Connector geometry, in stage coordinates. Keys are `from>to`. File tokens and arrows travel along these exact paths. */
export const SEGMENTS = {
  'source>client': 'M125 112 L125 300',
  'client>dazstr': 'M125 300 L450 300',
  'dazstr>pgp': 'M450 300 C450 170 540 110 665 110',
  'pgp>ready': 'M665 110 C790 110 880 180 880 300',
  'dazstr>ready': 'M450 300 L880 300',
  'ready>artiva': 'M880 300 L1265 300',
  'ready>score': 'M880 300 C780 320 720 380 710 520',
  'ready>archive': 'M880 300 C980 320 1040 380 1050 520',
};

const SEG_META = {
  'source>client': { color: 'client' },
  'client>dazstr': { color: 'client' },
  'dazstr>pgp': { color: 'pgp', label: 'locked .pgp files', lx: 352, ly: 152, lw: 120, align: 'right' },
  'pgp>ready': { color: 'pgp', label: 'now readable', lx: 832, ly: 132 },
  'dazstr>ready': { color: 'dazstr', label: 'readable files go straight', lx: 556, ly: 310 },
  'ready>artiva': { color: 'artiva', dashed: true, label: 'Artiva program takes over', lx: 962, ly: 274 },
  'ready>score': { color: 'score', dashed: true, label: 'copy → quality check', lx: 580, ly: 368, lw: 150, align: 'right' },
  'ready>archive': { color: 'archive', dashed: true, label: 'copy → archive', lx: 1032, ly: 368 },
};

const SAMPLE_FILES = [
  { name: 'placements_1029_a.csv.pgp', encrypted: true },
  { name: 'payments_1029.txt', encrypted: false },
  { name: 'recalls_1029.csv.pgp', encrypted: true },
  { name: 'account_updates_1029.txt', encrypted: false },
  { name: 'new_business_b2.csv.pgp', encrypted: true },
  { name: 'closures_1029.txt', encrypted: false },
];

const DEMO_FILES = {
  1: { fileId: 'demo-1', fileName: 'placements_1029.csv.pgp', encrypted: true },
  2: { fileId: 'demo-2', fileName: 'payments_1029.txt', encrypted: false },
};

/** Scripted walkthrough. `spot` = stages highlighted during the step. */
export const DEMO_STEPS = [
  { ms: 2400, spot: [], title: 'Watch one file make the trip', text: 'We’ll follow a single file from {client} all the way into Artiva.', events: [] },
  { ms: 3000, spot: ['client'], title: 'The client drops a file', text: '{client} uploads a locked (PGP) file to their own SFTP server. iResolve notices it by itself.', events: [{ f: 1, stage: 'client' }] },
  { ms: 3000, spot: ['dazstr'], title: 'iResolve collects it', text: 'The file is pulled into dazstr, CRM’s own secure SFTP server. From here on it’s inside CRM.', events: [{ f: 1, stage: 'dazstr' }] },
  { ms: 3200, spot: ['pgp'], title: 'Locked? iResolve unlocks it', text: 'Because the file arrived locked, iResolve opens it with CRM’s private key. Watch the padlock disappear.', events: [{ f: 1, stage: 'pgp' }] },
  { ms: 3000, spot: ['ready'], title: 'Ready for hand-off', text: 'The readable file lands in dazstr’s ready folder — the end of iResolve’s delivery job.', events: [{ f: 1, stage: 'ready' }] },
  { ms: 3800, spot: ['score', 'archive'], title: 'Copies branch off — nothing waits', text: 'One copy is quality-checked and scored (92/100); another is archived. The file itself is never held up.', events: [{ f: 1, stage: 'score', score: 92 }, { f: 1, stage: 'archive' }] },
  { ms: 3200, spot: ['artiva'], title: 'Artiva takes over', text: 'A separate Artiva program moves the file into Artiva EFS, where collection work begins.', events: [{ f: 1, stage: 'artiva' }] },
  { ms: 2600, spot: ['client'], title: 'Now a file that isn’t locked', text: 'Some files arrive already readable. Watch the shortcut.', events: [{ f: 2, stage: 'client' }] },
  { ms: 2200, spot: ['dazstr'], title: 'Collected the same way', text: 'It’s pulled into dazstr exactly like before.', events: [{ f: 2, stage: 'dazstr' }] },
  { ms: 3000, spot: ['ready'], title: 'It skips the unlock step', text: 'Readable files go straight to the ready folder.', events: [{ f: 2, stage: 'ready' }] },
  { ms: 3600, spot: ['score', 'archive', 'artiva'], title: 'Same checks, same archive, same hand-off', text: 'It’s scored (85/100), archived and handed to Artiva exactly like the first file.', events: [{ f: 2, stage: 'score', score: 85 }, { f: 2, stage: 'archive' }, { f: 2, stage: 'artiva' }] },
  { ms: 0, spot: [], end: true, title: 'That’s the whole journey', text: 'Every step runs by itself, around the clock. Switch to Live to watch {client}’s real files.', events: [] },
];

/* ------------------------------------------------------------------ */
/* Helpers                                                             */
/* ------------------------------------------------------------------ */

const cx = (...a) => a.filter(Boolean).join(' ');
const nFiles = (n) => `${n} file${n === 1 ? '' : 's'}`;
const stripPgp = (name) => String(name || '').replace(/\.pgp$/i, '');
const fmtTime = (d) => {
  const date = d instanceof Date ? d : new Date(d);
  return Number.isNaN(date.getTime()) ? '--:--:--' : date.toLocaleTimeString('en-GB');
};

function messageFor(stage, file) {
  switch (stage) {
    case 'client': return file.encrypted ? 'Locked file spotted on client SFTP' : 'New file spotted on client SFTP';
    case 'dazstr': return 'Pulled into iResolve SFTP (dazstr)';
    case 'pgp': return 'PGP lock removed with CRM key';
    case 'ready': return 'Ready on dazstr for hand-off';
    case 'score':
      return file.flagged
        ? `Scored ${file.score}/100 · flagged for review, still delivered`
        : `Scored ${file.score ?? '—'}/100 · looks good`;
    case 'archive': return 'Copy saved to archive';
    case 'artiva': return 'Moved to Artiva EFS by the Artiva program';
    default: return '';
  }
}

/* ------------------------------------------------------------------ */
/* State                                                               */
/* ------------------------------------------------------------------ */

const zero = () => Object.fromEntries(STAGE_ORDER.map((k) => [k, 0]));

const initialState = () => ({
  files: {}, // fileId -> { id, name, encrypted, score, flagged, times: {stage: 'HH:MM:SS'}, lastMain, order }
  fileSeq: 0,
  counts: zero(),
  current: Object.fromEntries(STAGE_ORDER.map((k) => [k, 'waiting for files…'])),
  arrivals: zero(), // increments per arrival — used as a React key to replay the arrival ring
  lastArrival: {}, // stage -> epoch ms (drives the "busy" icon animation)
  errors: {}, // stage -> message | null
  hops: [], // tokens currently travelling: { key, fileId, seg, to, kind, locked, label }
  log: [], // newest first
  flagged: 0,
  lastScore: null,
  lastMovement: null,
});

function applyEvent(state, { ev, hopKey, animate, nowMs, flagBelow }) {
  const { stage } = ev;
  if (!STAGES[stage] || ev.fileId == null) return state;
  const prev = state.files[ev.fileId];
  const file = prev
    ? { ...prev, times: { ...prev.times } }
    : { id: ev.fileId, name: ev.fileName || String(ev.fileId), encrypted: !!ev.encrypted, score: null, flagged: false, times: {}, lastMain: null, order: state.fileSeq + 1 };
  if (prev && ev.encrypted && !prev.encrypted && !prev.times.pgp) file.encrypted = true;

  const isError = ev.status === 'error';
  const lockedBefore = file.encrypted && !file.times.pgp;
  const from = stage === 'client' ? 'source' : COPY_STAGES.includes(stage) ? 'ready' : file.lastMain;
  const timeStr = fmtTime(ev.time ?? new Date());

  let flaggedInc = 0;
  let { lastScore } = state;
  if (!isError) {
    file.times[stage] = timeStr;
    if (MAIN_STAGES.includes(stage)) file.lastMain = stage;
    if (stage === 'score' && ev.score != null) {
      file.score = ev.score;
      file.flagged = ev.flagged ?? ev.score < flagBelow;
      if (file.flagged && !(prev && prev.flagged)) flaggedInc = 1;
      lastScore = ev.score;
    }
  }
  const shownName = file.encrypted && !file.times.pgp ? file.name : stripPgp(file.name);

  let { hops } = state;
  const seg = from ? `${from}>${stage}` : null;
  if (animate && !isError && seg && SEGMENTS[seg]) {
    const kind = COPY_STAGES.includes(stage) ? 'copy' : 'main';
    if (kind === 'main') hops = hops.filter((h) => !(h.fileId === file.id && h.kind === 'main'));
    hops = [...hops, {
      key: hopKey, fileId: file.id, seg, to: stage, kind,
      locked: kind === 'main' && lockedBefore,
      label: kind === 'copy' ? (stage === 'score' ? 'copy → scoring' : 'copy → archive') : (lockedBefore ? file.name : stripPgp(file.name)),
    }];
  }

  let files = { ...state.files, [file.id]: file };
  const ids = Object.keys(files);
  if (ids.length > FILE_MAX) {
    const oldest = ids.sort((a, b) => files[a].order - files[b].order)[0];
    files = { ...files };
    delete files[oldest];
  }

  return {
    ...state,
    files,
    fileSeq: prev ? state.fileSeq : state.fileSeq + 1,
    hops,
    counts: isError ? state.counts : { ...state.counts, [stage]: state.counts[stage] + 1 },
    current: { ...state.current, [stage]: shownName },
    arrivals: { ...state.arrivals, [stage]: state.arrivals[stage] + 1 },
    lastArrival: animate ? { ...state.lastArrival, [stage]: nowMs } : state.lastArrival,
    errors: { ...state.errors, [stage]: isError ? (ev.message || 'Something went wrong at this step') : null },
    flagged: state.flagged + flaggedInc,
    lastScore,
    lastMovement: timeStr,
    log: [{
      key: hopKey, fileId: file.id, time: timeStr, file: shownName, stage,
      msg: ev.message || messageFor(stage, file),
      level: isError ? 'error' : stage === 'score' && file.flagged ? 'warn' : 'ok',
    }, ...state.log].slice(0, LOG_MAX),
  };
}

function reducer(state, action) {
  switch (action.type) {
    case 'reset': return initialState();
    case 'event': return applyEvent(state, action);
    case 'hopDone': return { ...state, hops: state.hops.filter((h) => h.key !== action.key) };
    case 'note': return { ...state, log: [action.entry, ...state.log].slice(0, LOG_MAX) };
    default: return state;
  }
}

/* ------------------------------------------------------------------ */
/* Icons (Lucide-based, MIT). Parts with class `sfj-a` animate only while the stage is busy. */
/* ------------------------------------------------------------------ */

const svgBase = { viewBox: '0 0 24 24', fill: 'none', stroke: 'currentColor', strokeLinecap: 'round', strokeLinejoin: 'round', 'aria-hidden': true, focusable: 'false' };

function StageIcon({ id }) {
  const p = { ...svgBase, width: id === 'dazstr' ? 42 : 34, height: id === 'dazstr' ? 42 : 34, strokeWidth: id === 'dazstr' ? 1.7 : 1.8 };
  switch (id) {
    case 'client': // server
      return (
        <svg {...p}>
          <rect width="20" height="8" x="2" y="2" rx="2" />
          <rect width="20" height="8" x="2" y="14" rx="2" />
          <line className="sfj-a sfj-a-blink" x1="6" x2="6.01" y1="6" y2="6" strokeWidth="2.6" />
          <line className="sfj-a sfj-a-blink sfj-d2" x1="6" x2="6.01" y1="18" y2="18" strokeWidth="2.6" />
          <line className="sfj-a sfj-a-fade" x1="10" x2="18" y1="6" y2="6" />
          <line className="sfj-a sfj-a-fade sfj-d2" x1="10" x2="18" y1="18" y2="18" />
        </svg>
      );
    case 'dazstr': // shield-check
      return (
        <svg {...p}>
          <path d="M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z" />
          <path className="sfj-a sfj-a-draw" d="m9 12 2 2 4-4" pathLength="100" />
        </svg>
      );
    case 'pgp': // lock → lock-open
      return (
        <svg {...p}>
          <path className="sfj-a sfj-a-unlock" d="M7 11V7a5 5 0 0 1 10 0v4" />
          <rect width="18" height="11" x="3" y="11" rx="2" className="sfj-fill-surf" />
          <circle className="sfj-a sfj-a-blink" cx="12" cy="16" r="1.2" fill="currentColor" />
          <path d="M12 17.2v1.8" />
        </svg>
      );
    case 'ready': // folder-check
      return (
        <svg {...p}>
          <path d="M20 20a2 2 0 0 0 2-2V8a2 2 0 0 0-2-2h-7.9a2 2 0 0 1-1.69-.9L9.6 3.9A2 2 0 0 0 7.93 3H4a2 2 0 0 0-2 2v13a2 2 0 0 0 2 2Z" />
          <path className="sfj-a sfj-a-draw" d="m9 13 2 2 4-4" pathLength="100" />
        </svg>
      );
    case 'score': // gauge
      return (
        <svg {...p}>
          <path d="M3.34 19a10 10 0 1 1 17.32 0" />
          <path className="sfj-a sfj-a-needle" d="M12 14l4-4" strokeWidth="2.2" />
          <circle cx="12" cy="14" r="1.4" fill="currentColor" />
        </svg>
      );
    case 'archive': // archive
      return (
        <svg {...p}>
          <path d="M4 8v11a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8" />
          <path d="M10 12h4" />
          <rect className="sfj-a sfj-a-lid sfj-fill-surf" width="20" height="5" x="2" y="3" rx="1" />
        </svg>
      );
    case 'artiva': // database
      return (
        <svg {...p}>
          <ellipse cx="12" cy="5" rx="9" ry="3" />
          <path d="M3 5V19A9 3 0 0 0 21 19V5" />
          <path className="sfj-a sfj-a-fade" d="M3 12A9 3 0 0 0 21 12" />
          <path className="sfj-a sfj-a-fade sfj-d2" d="M3 16A9 3 0 0 0 21 16" strokeOpacity=".6" />
        </svg>
      );
    default:
      return null;
  }
}

const Icon = {
  building: (props) => (
    <svg {...svgBase} width="26" height="26" strokeWidth="1.8" {...props}>
      <path d="M6 22V4a2 2 0 0 1 2-2h8a2 2 0 0 1 2 2v18Z" />
      <path d="M6 12H4a2 2 0 0 0-2 2v6a2 2 0 0 0 2 2h2" />
      <path d="M18 9h2a2 2 0 0 1 2 2v9a2 2 0 0 1-2 2h-2" />
      <path className="sfj-a sfj-a-fade" d="M10 6h4" />
      <path className="sfj-a sfj-a-fade sfj-d2" d="M10 10h4" />
      <path className="sfj-a sfj-a-fade" d="M10 14h4" />
      <path className="sfj-a sfj-a-fade sfj-d2" d="M10 18h4" />
    </svg>
  ),
  lock: (props) => (
    <svg {...svgBase} width="14" height="14" strokeWidth="2.2" {...props}>
      <rect width="18" height="11" x="3" y="11" rx="2" />
      <path d="M7 11V7a5 5 0 0 1 10 0v4" />
    </svg>
  ),
  file: (props) => (
    <svg {...svgBase} width="14" height="14" strokeWidth="2" {...props}>
      <path d="M15 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7Z" />
      <path d="M14 2v4a2 2 0 0 0 2 2h4" />
      <path d="M16 13H8" />
      <path d="M16 17H8" />
    </svg>
  ),
  copy: (props) => (
    <svg {...svgBase} width="12" height="12" strokeWidth="2" {...props}>
      <rect width="14" height="14" x="8" y="8" rx="2" />
      <path d="M4 16c-1.1 0-2-.9-2-2V4c0-1.1.9-2 2-2h10c1.1 0 2 .9 2 2" />
    </svg>
  ),
  play: (props) => (
    <svg {...svgBase} width="16" height="16" strokeWidth="2" {...props}>
      <path d="M6 4l14 8-14 8z" fill="currentColor" />
    </svg>
  ),
  pause: (props) => (
    <svg {...svgBase} width="16" height="16" strokeWidth="2" {...props}>
      <rect x="6" y="4" width="4" height="16" rx="1" fill="currentColor" />
      <rect x="14" y="4" width="4" height="16" rx="1" fill="currentColor" />
    </svg>
  ),
  replay: (props) => (
    <svg {...svgBase} width="16" height="16" strokeWidth="2" {...props}>
      <path d="M3 12a9 9 0 1 0 9-9 9.75 9.75 0 0 0-6.74 2.74L3 8" />
      <path d="M3 3v5h5" />
    </svg>
  ),
  next: (props) => (
    <svg {...svgBase} width="16" height="16" strokeWidth="2" {...props}>
      <path d="m6 17 5-5-5-5" />
      <path d="m13 17 5-5-5-5" />
    </svg>
  ),
  chevL: (props) => (<svg {...svgBase} width="16" height="16" strokeWidth="2" {...props}><path d="m15 18-6-6 6-6" /></svg>),
  chevR: (props) => (<svg {...svgBase} width="16" height="16" strokeWidth="2" {...props}><path d="m9 18 6-6-6-6" /></svg>),
  pulse: (props) => (<svg {...svgBase} width="16" height="16" strokeWidth="2" {...props}><path d="M3 12h4l3 8 4-16 3 8h4" /></svg>),
  info: (props) => (<svg {...svgBase} width="17" height="17" strokeWidth="2" {...props}><circle cx="12" cy="12" r="10" /><path d="M12 16v-4" /><path d="M12 8h.01" /></svg>),
  check: (props) => (<svg {...svgBase} width="17" height="17" strokeWidth="2" {...props}><circle cx="12" cy="12" r="10" /><path d="m9 12 2 2 4-4" /></svg>),
  alert: (props) => (<svg {...svgBase} width="17" height="17" strokeWidth="2" {...props}><path d="m21.73 18-8-14a2 2 0 0 0-3.48 0l-8 14A2 2 0 0 0 4 21h16a2 2 0 0 0 1.73-3" /><path d="M12 9v4" /><path d="M12 17h.01" /></svg>),
};

/* ------------------------------------------------------------------ */
/* Component                                                           */
/* ------------------------------------------------------------------ */

/**
 * @param {object}  props
 * @param {string}  [props.clientName]   Display name of the client.
 * @param {object}  [props.hosts]        { clientSftp, dazstr, readyFolder, archive, artivaEfs } — shown under each stage.
 * @param {'dark'|'light'} [props.theme] Map this to iResolve's theme toggle.
 * @param {'connected'|'unreachable'} [props.connection] Client SFTP connection status.
 * @param {Array}   [props.events]       Live events (see spec). Omit to run the built-in sample simulator in Live mode.
 * @param {'demo'|'live'} [props.defaultMode] Defaults to 'live' when `events` is passed, otherwise 'demo'.
 * @param {number}  [props.flagBelow]    Scores below this are shown as "flagged" when the event has no `flagged` field.
 * @param {string}  [props.className]
 */
export default function SftpFlowJourney({
  clientName = '[Client name]',
  hosts = {},
  theme = 'dark',
  connection = 'connected',
  events,
  defaultMode,
  flagBelow = 78,
  className = '',
}) {
  const [mode, setMode] = useState(defaultMode || (events ? 'live' : 'demo'));
  const [state, dispatch] = useReducer(reducer, undefined, initialState);
  const [selected, setSelected] = useState('client');
  const [focusId, setFocusId] = useState(null);
  const [demo, setDemo] = useState({ status: 'idle', step: -1 }); // idle | playing | paused | done
  const [now, setNow] = useState(() => Date.now());
  const [layout, setLayout] = useState({ scale: 1, offset: 0 });

  const wrapRef = useRef(null);
  const timers = useRef(new Set());
  const hopSeq = useRef(0);
  const seenIds = useRef(new Set());
  const emittedStep = useRef(-1);
  const connRef = useRef(connection);
  const flagRef = useRef(flagBelow);
  connRef.current = connection;
  flagRef.current = flagBelow;

  const down = connection === 'unreachable';
  const fill = useCallback((t) => String(t).split('{client}').join(clientName), [clientName]);

  /* timers */
  const later = useCallback((fn, ms) => {
    const id = setTimeout(() => { timers.current.delete(id); fn(); }, ms);
    timers.current.add(id);
    return id;
  }, []);
  const clearTimers = useCallback(() => {
    timers.current.forEach((id) => clearTimeout(id));
    timers.current.clear();
  }, []);
  useEffect(() => () => clearTimers(), [clearTimers]);

  /* one event in → state + travelling token */
  const emit = useCallback((ev, animate = true) => {
    hopSeq.current += 1;
    const key = `h${hopSeq.current}`;
    dispatch({ type: 'event', ev, hopKey: key, animate, nowMs: Date.now(), flagBelow: flagRef.current });
    if (animate) later(() => dispatch({ type: 'hopDone', key }), HOP_MS + 200);
  }, [later]);

  /* clock for the "busy" icon state */
  useEffect(() => {
    const iv = setInterval(() => setNow(Date.now()), 300);
    return () => clearInterval(iv);
  }, []);

  /* responsive scaling of the fixed-size stage */
  useLayoutEffect(() => {
    const el = wrapRef.current;
    if (!el) return undefined;
    const measure = () => {
      const w = el.clientWidth;
      const scale = Math.min(1, w / STAGE_W);
      setLayout({ scale, offset: Math.max(0, (w - STAGE_W) / 2) });
    };
    measure();
    if (typeof ResizeObserver === 'undefined') return undefined;
    const ro = new ResizeObserver(measure);
    ro.observe(el);
    return () => ro.disconnect();
  }, []);

  /* LIVE — real events from the backend */
  useEffect(() => {
    if (mode !== 'live' || !events) return;
    const firstLoad = seenIds.current.size === 0;
    events.forEach((ev, i) => {
      const id = ev.id ?? `${ev.fileId}:${ev.stage}:${ev.time ?? i}`;
      if (seenIds.current.has(id)) return;
      seenIds.current.add(id);
      emit(ev, !firstLoad); // history on first load is applied without animation
    });
  }, [mode, events, emit]);

  /* LIVE — sample simulator when no events are wired yet */
  useEffect(() => {
    if (mode !== 'live' || events) return undefined;
    let n = 0;
    const spawn = () => {
      if (connRef.current === 'unreachable') {
        dispatch({ type: 'note', entry: { key: `r${Date.now()}`, fileId: null, time: fmtTime(new Date()), file: 'client SFTP', stage: 'client', msg: 'Not answering — retrying automatically', level: 'error' } });
        return;
      }
      const spec = SAMPLE_FILES[n % SAMPLE_FILES.length];
      n += 1;
      const base = { fileId: `sample-${Date.now()}-${n}`, fileName: spec.name, encrypted: spec.encrypted };
      const route = spec.encrypted ? ['client', 'dazstr', 'pgp', 'ready'] : ['client', 'dazstr', 'ready'];
      route.forEach((stage, i) => later(() => emit({ ...base, stage, time: new Date().toISOString() }), i * SIM_STEP_MS));
      later(() => {
        const t = new Date().toISOString();
        emit({ ...base, stage: 'score', score: 74 + Math.floor(Math.random() * 26), time: t });
        emit({ ...base, stage: 'archive', time: t });
        emit({ ...base, stage: 'artiva', time: t });
      }, route.length * SIM_STEP_MS);
    };
    spawn();
    const iv = setInterval(spawn, SIM_SPAWN_MS);
    return () => { clearInterval(iv); clearTimers(); };
  }, [mode, events, emit, later, clearTimers]);

  /* DEMO — scripted walkthrough */
  useEffect(() => {
    if (mode !== 'demo' || demo.status !== 'playing') return undefined;
    const step = DEMO_STEPS[demo.step];
    if (!step) return undefined;
    if (emittedStep.current !== demo.step) {
      emittedStep.current = demo.step;
      step.events.forEach((e) => emit({ ...DEMO_FILES[e.f], stage: e.stage, score: e.score, time: new Date().toISOString() }));
      if (step.spot.length) setSelected(step.spot[0]);
      setFocusId(null);
    }
    if (step.end) {
      setDemo({ status: 'done', step: demo.step });
      return undefined;
    }
    const t = setTimeout(() => setDemo((d) => (d.status === 'playing' ? { ...d, step: d.step + 1 } : d)), step.ms);
    return () => clearTimeout(t);
  }, [mode, demo, emit]);

  const resetAll = () => {
    clearTimers();
    dispatch({ type: 'reset' });
    seenIds.current = new Set();
    emittedStep.current = -1;
    setFocusId(null);
  };
  const playDemo = () => { resetAll(); setSelected('client'); setDemo({ status: 'playing', step: 0 }); };
  const pauseDemo = () => setDemo((d) => ({ ...d, status: 'paused' }));
  const resumeDemo = () => setDemo((d) => ({ ...d, status: 'playing' }));
  const nextStep = () => setDemo((d) => (d.step < DEMO_STEPS.length - 1 ? { status: 'playing', step: d.step + 1 } : d));
  const switchMode = (m) => {
    if (m === mode) return;
    resetAll();
    setDemo({ status: 'idle', step: -1 });
    setMode(m);
  };

  /* ---------- derived ---------- */
  const activeSegs = new Set(state.hops.map((h) => h.seg));
  const isBusy = (id) => now - (state.lastArrival[id] ?? -1e12) < BUSY_MS;
  const demoStep = mode === 'demo' && demo.step >= 0 ? DEMO_STEPS[demo.step] : null;
  const spot = demoStep && (demo.status === 'playing' || demo.status === 'paused') && demoStep.spot.length ? new Set(demoStep.spot) : null;
  const inFlight = Object.values(state.files).filter((f) => f.times.client && !f.times.artiva).length;
  const errorStage = STAGE_ORDER.find((k) => state.errors[k]);

  let statusText;
  let statusBad = false;
  if (down) {
    statusText = `We can’t reach ${clientName}’s server right now. iResolve keeps retrying by itself — nothing is lost.`;
    statusBad = true;
  } else if (mode === 'live' && errorStage) {
    statusText = `Attention needed at “${STAGES[errorStage].title}”: ${state.errors[errorStage]}`;
    statusBad = true;
  } else if (mode === 'demo') {
    statusText = demo.status === 'idle'
      ? `Press Play to see how ${clientName}’s files travel — every step is automatic.`
      : demo.status === 'done' ? 'Demo finished — replay it, or switch to Live.' : 'Demo · sample files';
  } else {
    statusText = `All systems normal — ${inFlight} file${inFlight === 1 ? '' : 's'} on the way.${state.flagged ? ` ${state.flagged} flagged for review, still delivered.` : ''}`;
  }

  const hostLine = {
    client: hosts.clientSftp || '[client-sftp-host]',
    dazstr: `host · ${hosts.dazstr || 'dazstr'}`,
    pgp: 'CRM private key',
    ready: hosts.readyFolder || '[ready-folder]',
    score: 'side branch · never blocks',
    archive: hosts.archive || '[archive-path]',
    artiva: hosts.artivaEfs || '[artiva-efs-path]',
  };

  const statusLine = (id) => {
    const c = state.counts[id];
    if (state.errors[id]) return { text: state.errors[id], tone: 'bad', led: true };
    switch (id) {
      case 'client': return down ? { text: 'Not answering · retrying', tone: 'bad', led: true } : { text: `Connected · ${nFiles(c)}`, tone: 'ok', led: true };
      case 'dazstr': return { text: `Online · ${nFiles(c)}`, tone: 'ok', led: true };
      case 'pgp': return { text: `Only locked files · ${c}`, tone: 'acc' };
      case 'ready': return { text: `Handed over · ${nFiles(c)}`, tone: 'ok', led: true };
      case 'score': return { text: `last score ${state.lastScore != null ? `${state.lastScore}/100` : '—'}`, tone: 'acc', mono: true };
      case 'archive': return { text: `Kept on record · ${c}`, tone: 'acc' };
      case 'artiva': return { text: `via Artiva program · ${c}`, tone: 'acc' };
      default: return { text: '' };
    }
  };

  const selectStage = (id) => { setSelected(id); setFocusId(null); };
  const selIdx = STAGE_ORDER.indexOf(selected);
  const sel = STAGES[selected];
  const focusFile = focusId ? state.files[focusId] : null;

  /* ---------- render ---------- */
  return (
    <section className={cx('sfj', className)} data-theme={theme === 'light' ? 'light' : 'dark'} aria-label={`File journey for ${clientName}`}>
      {/* Header */}
      <header className="sfj-header">
        <div className="sfj-head-text">
          <div className="sfj-eyebrow"><Icon.pulse /> SFTP CONTROL CENTRE · FILE JOURNEY</div>
          <h2 className="sfj-title">{clientName}</h2>
          <p className={cx('sfj-status', statusBad && 'is-bad')} role="status" aria-live="polite">
            <span className={cx('sfj-led', statusBad && 'is-bad', mode === 'live' && !statusBad && 'is-live')} />
            {statusText}
          </p>
        </div>
        <div className="sfj-head-ctl">
          <div className="sfj-modes" role="group" aria-label="View">
            <button type="button" aria-pressed={mode === 'demo'} onClick={() => switchMode('demo')}>Demo</button>
            <button type="button" aria-pressed={mode === 'live'} onClick={() => switchMode('live')}>Live</button>
          </div>
          {mode === 'demo' ? (
            <>
              {demo.status === 'idle' && <button type="button" className="sfj-btn is-primary" onClick={playDemo}><Icon.play /> Play demo</button>}
              {demo.status === 'playing' && <button type="button" className="sfj-btn is-primary" onClick={pauseDemo}><Icon.pause /> Pause</button>}
              {demo.status === 'paused' && <button type="button" className="sfj-btn is-primary" onClick={resumeDemo}><Icon.play /> Resume</button>}
              {demo.status === 'done' && <button type="button" className="sfj-btn is-primary" onClick={playDemo}><Icon.replay /> Replay</button>}
            </>
          ) : (
            <span className={cx('sfj-live', down && 'is-bad')}><span className={cx('sfj-led', down ? 'is-bad' : 'is-live')} />{down ? 'ATTENTION' : 'LIVE'}</span>
          )}
          <div className="sfj-tile"><span>Picked up</span><strong>{state.counts.client}</strong></div>
          <div className="sfj-tile"><span>On the way</span><strong className="is-primary">{inFlight}</strong></div>
          <div className="sfj-tile"><span>Flagged, still sent</span><strong className="is-warn">{state.flagged}</strong></div>
          <div className="sfj-tile"><span>Last movement</span><strong className="is-time">{state.lastMovement || '—'}</strong></div>
        </div>
      </header>

      {/* Flow stage */}
      <div className="sfj-stage-wrap" ref={wrapRef} style={{ height: STAGE_H * layout.scale }}>
        <div
          className={cx('sfj-stage', spot && 'is-spotlight')}
          style={{ width: STAGE_W, height: STAGE_H, transform: `scale(${layout.scale})`, marginLeft: layout.offset }}
        >
          <div className="sfj-zone" style={{ left: 250 }} aria-hidden="true" />
          <div className="sfj-zone" style={{ left: 1130 }} aria-hidden="true" />
          <div className="sfj-zone-label" style={{ left: 20 }}>CLIENT</div>
          <div className="sfj-zone-label" style={{ left: 268 }}>CRM · iRESOLVE <span>— fully automatic</span></div>
          <div className="sfj-zone-label" style={{ left: 1146 }}>ARTIVA <span>— separate program</span></div>

          {/* Client "source" */}
          <div className={cx('sfj-source', 'sfj-anim-scope', isBusy('client') && 'is-busy')} aria-hidden="true">
            <div className="sfj-source-ic"><Icon.building /></div>
            <div className="sfj-source-txt"><strong>{clientName}</strong><span>uploads files</span></div>
          </div>

          {/* Connectors */}
          <svg className="sfj-lines" width={STAGE_W} height={STAGE_H} viewBox={`0 0 ${STAGE_W} ${STAGE_H}`} aria-hidden="true">
            {Object.entries(SEGMENTS).map(([key, d]) => {
              const meta = SEG_META[key];
              const bad = down && (key === 'client>dazstr' || key === 'source>client');
              return (
                <g key={key} className={cx('sfj-seg', `acc-${meta.color}`, meta.dashed && 'is-branch', activeSegs.has(key) && !bad && 'is-active', bad && 'is-bad')}>
                  <path className="sfj-seg-base" d={d} />
                  <path className="sfj-seg-flow" d={d} />
                  <path className="sfj-seg-comet" d={d} pathLength="100" />
                </g>
              );
            })}
          </svg>

          {/* Direction arrows: one static arrow per connector, moving chevrons while a file travels on it */}
          {Object.entries(SEGMENTS).map(([key, d]) => {
            const meta = SEG_META[key];
            const bad = down && (key === 'client>dazstr' || key === 'source>client');
            const active = activeSegs.has(key) && !bad;
            return (
              <div key={key} aria-hidden="true">
                <div className={cx('sfj-arrow', `acc-${meta.color}`, active && 'is-hidden', bad && 'is-bad')} style={{ offsetPath: `path('${d}')` }} />
                {active && [0, 1, 2].map((i) => (
                  <div key={i} className={cx('sfj-chev', `acc-${meta.color}`)} style={{ offsetPath: `path('${d}')`, animationDelay: `${-i * 0.42}s` }} />
                ))}
              </div>
            );
          })}

          {/* Connector captions */}
          {Object.entries(SEG_META).filter(([, m]) => m.label).map(([key, m]) => (
            <div key={key} className={cx('sfj-seg-label', `acc-${m.color}`)} style={{ left: m.lx, top: m.ly, width: m.lw, textAlign: m.align || 'left' }}>{m.label}</div>
          ))}
          <div className="sfj-handoff" style={{ left: 1123, top: 293 }} aria-hidden="true" />

          {/* Stages */}
          {STAGE_ORDER.map((id) => {
            const s = STAGES[id];
            const line = statusLine(id);
            const bad = (id === 'client' && down) || !!state.errors[id];
            const r = s.hub ? 50 : 42;
            return (
              <button
                key={id}
                type="button"
                className={cx('sfj-node', 'sfj-anim-scope', `acc-${id}`, s.hub && 'is-hub', bad && 'is-bad', isBusy(id) && 'is-busy', selected === id && 'is-selected', spot && !spot.has(id) && 'is-dimmed')}
                style={{ left: s.x - 90, top: s.y - r }}
                onClick={() => selectStage(id)}
                aria-label={`Stage ${STAGE_ORDER.indexOf(id) + 1}: ${s.title}. ${line.text}. Show explanation.`}
              >
                <span className="sfj-badge">
                  <span className="sfj-arc" />
                  {state.arrivals[id] > 0 && <span key={state.arrivals[id]} className="sfj-ring" />}
                  <StageIcon id={id} />
                  {line.led && <span className={cx('sfj-dot', line.tone === 'bad' && 'is-bad')} />}
                </span>
                <span className="sfj-plate">
                  <span className="sfj-plate-title">{s.title}</span>
                  <span className="sfj-plate-host">{hostLine[id]}</span>
                  <span className={cx('sfj-plate-status', `tone-${line.tone}`, line.mono && 'is-mono')}>
                    {line.led && <span className={cx('sfj-led', line.tone === 'bad' && 'is-bad')} />}
                    {line.text}
                  </span>
                  <span className="sfj-plate-cur">› {state.current[id]}</span>
                </span>
              </button>
            );
          })}

          {/* Travelling files */}
          {state.hops.map((h) => (
            <div
              key={h.key}
              className={cx('sfj-tok', `acc-${h.to}`, h.kind === 'copy' && 'is-copy', h.to === 'artiva' && 'is-ext')}
              style={{ offsetPath: `path('${SEGMENTS[h.seg]}')` }}
              aria-hidden="true"
            >
              {h.kind === 'copy' ? <Icon.copy className="sfj-tok-ic" /> : h.locked ? <Icon.lock className="sfj-tok-ic is-locked" /> : <Icon.file className="sfj-tok-ic" />}
              <span>{h.label}</span>
            </div>
          ))}

          {/* Legend */}
          <div className="sfj-legend">
            <div className="sfj-legend-title">HOW TO READ THIS</div>
            <div><span className="sfj-chip acc-pgp"><Icon.lock /></span>Locked file (PGP)</div>
            <div><span className="sfj-chip acc-dazstr"><Icon.file /></span>Readable file</div>
            <div><span className="sfj-chip is-dashed acc-score" />Copy on a side branch</div>
            <div><span className="sfj-chevs acc-dazstr" aria-hidden="true">›››</span>Direction of travel</div>
            <div><span className="sfj-led is-bad sfj-legend-led" />Red = needs attention</div>
          </div>

          {/* Demo: start overlay */}
          {mode === 'demo' && demo.status === 'idle' && (
            <div className="sfj-overlay">
              <div className="sfj-overlay-card">
                <button type="button" className="sfj-bigplay" onClick={playDemo} aria-label="Play demo">
                  <Icon.play width="34" height="34" />
                </button>
                <h3>See how {clientName}’s files travel</h3>
                <p>A 40-second walkthrough of every step, from the client’s server to Artiva. Nothing here needs a person to step in.</p>
                <button type="button" className="sfj-link" onClick={() => switchMode('live')}>or watch live activity</button>
              </div>
            </div>
          )}

          {/* Demo: step caption */}
          {mode === 'demo' && demo.status !== 'idle' && demoStep && (
            <div className="sfj-caption" role="status" aria-live="polite">
              <div className="sfj-caption-top">
                <span className="sfj-caption-step">{demoStep.end ? 'DONE' : `STEP ${demo.step + 1} OF ${DEMO_STEPS.length - 1}`}</span>
                <span className="sfj-progress" aria-hidden="true">
                  <span style={{ width: `${Math.min(100, ((demo.step + 1) / (DEMO_STEPS.length - 1)) * 100)}%` }} />
                </span>
              </div>
              <h3>{fill(demoStep.title)}</h3>
              <p>{fill(demoStep.text)}</p>
              <div className="sfj-caption-ctl">
                {demo.status === 'playing' && <button type="button" className="sfj-btn" onClick={pauseDemo}><Icon.pause /> Pause</button>}
                {demo.status === 'paused' && <button type="button" className="sfj-btn" onClick={resumeDemo}><Icon.play /> Resume</button>}
                {demo.status !== 'done' && <button type="button" className="sfj-btn" onClick={nextStep}><Icon.next /> Next step</button>}
                {demo.status === 'done' && <button type="button" className="sfj-btn" onClick={playDemo}><Icon.replay /> Replay</button>}
                {demo.status === 'done' && <button type="button" className="sfj-btn is-primary" onClick={() => switchMode('live')}>Watch live</button>}
                {demo.status !== 'done' && <button type="button" className="sfj-btn is-ghost" onClick={playDemo}><Icon.replay /> Restart</button>}
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Bottom panels */}
      <div className="sfj-panels">
        <section className="sfj-panel sfj-log">
          <div className="sfj-panel-head">
            <h3>Live file movements</h3>
            <span>Tap a file to follow its whole journey{(mode === 'demo' || !events) ? ' · sample data' : ''}</span>
          </div>
          {state.log.length === 0 && <p className="sfj-empty">{mode === 'demo' ? 'Press Play to start the demo.' : 'Waiting for the next file…'}</p>}
          <ul>
            {state.log.map((e) => (
              <li key={e.key}>
                <button type="button" className={cx('sfj-logrow', `level-${e.level}`)} onClick={() => e.fileId != null && setFocusId(e.fileId)} disabled={e.fileId == null}>
                  <span className="sfj-mono sfj-fa">{e.time}</span>
                  <span className={cx('sfj-logdot', e.level === 'error' ? 'is-bad' : `acc-${e.stage}`)} />
                  <span className="sfj-mono sfj-ellipsis">{e.file}</span>
                  <span className="sfj-mu sfj-ellipsis">{e.msg}</span>
                  <Icon.chevR className="sfj-fa" />
                </button>
              </li>
            ))}
          </ul>
        </section>

        <section className="sfj-panel sfj-guide">
          {!focusFile ? (
            <>
              <div className="sfj-guide-head">
                <span className="sfj-kicker">STAGE {selIdx + 1} OF {STAGE_ORDER.length}</span>
                <span className="sfj-dots">
                  {STAGE_ORDER.map((k, i) => (
                    <button key={k} type="button" className={cx('sfj-pdot', `acc-${k}`, i === selIdx && 'is-on')} onClick={() => selectStage(k)} aria-label={`Stage ${i + 1}: ${STAGES[k].title}`} />
                  ))}
                </span>
              </div>
              <h3 className="sfj-guide-title">{sel.guideTitle}</h3>
              <div className="sfj-guide-body">
                <div><Icon.info className="sfj-sec-ic acc-client" /><p><strong>What happens. </strong>{fill(sel.what)}</p></div>
                <div><Icon.check className="sfj-sec-ic acc-artiva" /><p><strong>Why it matters. </strong>{fill(sel.why)}</p></div>
                <div><Icon.alert className="sfj-sec-ic acc-score" /><p><strong>If something’s wrong. </strong>{fill(sel.wrong)}</p></div>
              </div>
              <div className="sfj-guide-nav">
                <button type="button" className="sfj-btn" onClick={() => selectStage(STAGE_ORDER[(selIdx + STAGE_ORDER.length - 1) % STAGE_ORDER.length])}><Icon.chevL /> Previous</button>
                <button type="button" className="sfj-btn" onClick={() => selectStage(STAGE_ORDER[(selIdx + 1) % STAGE_ORDER.length])}>Next <Icon.chevR /></button>
              </div>
            </>
          ) : (
            <FileJourney file={focusFile} onBack={() => setFocusId(null)} />
          )}
        </section>
      </div>
    </section>
  );
}

function FileJourney({ file, onBack }) {
  const stages = file.encrypted ? STAGE_ORDER : STAGE_ORDER.filter((k) => k !== 'pgp');
  let nextFound = false;
  const rows = stages.map((k) => {
    const t = file.times[k];
    const done = !!t;
    let isNow = false;
    if (!done && !nextFound) { nextFound = true; isNow = true; }
    let note = '';
    if (k === 'client') note = file.encrypted ? 'arrived locked (.pgp)' : 'arrived readable';
    if (k === 'pgp') note = 'unlocked with CRM key';
    if (k === 'score') note = done ? `score ${file.score}/100${file.flagged ? ' · flagged, still delivered' : ' · looks good'}` : 'side branch · never blocks';
    if (k === 'archive') note = 'copy kept on record';
    if (k === 'artiva') note = 'moved by the Artiva program';
    return { k, done, isNow, note, time: done ? t : isNow ? 'in progress' : '—' };
  });
  const scored = file.times.score && file.score != null;
  return (
    <>
      <div className="sfj-guide-head">
        <span className="sfj-kicker">FILE JOURNEY</span>
        <button type="button" className="sfj-btn" onClick={onBack}><Icon.chevL /> Back to stage guide</button>
      </div>
      <h3 className="sfj-journey-name">{file.encrypted ? stripPgp(file.name) : file.name}</h3>
      <p className="sfj-mu sfj-journey-status">
        {file.times.artiva ? 'Delivered to Artiva EFS · journey complete' : file.encrypted ? `Arrived locked as ${file.name} · on its way` : 'On its way…'}
      </p>
      <ol className="sfj-timeline">
        {rows.map((r) => (
          <li key={r.k} className={cx(`acc-${r.k}`, r.done && 'is-done', r.isNow && 'is-now')}>
            <span className="sfj-tdot" />
            <span className="sfj-tl-text"><span>{STAGES[r.k].journey}</span><small>{r.note}</small></span>
            <span className="sfj-mono">{r.time}</span>
          </li>
        ))}
      </ol>
      <div className="sfj-score">
        <span className="sfj-mu">Quality score</span>
        <span className="sfj-score-track"><span style={{ width: `${scored ? file.score : 0}%` }} /></span>
        <span className="sfj-mono sfj-warn">{scored ? `${file.score}/100` : 'pending'}</span>
      </div>
    </>
  );
}
