/**
 * <IResolveLogo /> — React wrapper for iResolve Logo Motion (zero dependencies).
 *
 *   <IResolveLogo variant="login"  markSrc={markUrl} />   // big logo on the login page
 *   <IResolveLogo variant="topbar" markSrc={markUrl} />   // small logo in the top bar
 *
 * Any engine option can be passed as a prop (see README.md → Options), e.g.
 *   <IResolveLogo variant="topbar" markSrc={markUrl} idle={{ every: 12000 }} />
 * Use `onReady={(logo) => ...}` to get the controller: logo.replay(), logo.spin(), logo.setSpeed(x), logo.destroy().
 *
 * Safe under React StrictMode: the dev double-mount is cleaned up and the intro still plays.
 */
import { useEffect, useRef } from 'react';
import './logoMotion.js';   // registers window.IResolveLogoMotion (keep this path pointing at logoMotion.js)
import './logoMotion.css';

export default function IResolveLogo({ variant = 'login', markSrc, className = '', style, ...options }) {
  const hostRef = useRef(null);
  const optionsRef = useRef(options);
  optionsRef.current = options;

  useEffect(() => {
    const engine = typeof window !== 'undefined' ? window.IResolveLogoMotion : null;
    if (!hostRef.current || !engine || !markSrc) return undefined;
    const logo = engine.mount(hostRef.current, { ...optionsRef.current, variant, markSrc });
    return () => logo.destroy();
  }, [variant, markSrc]);

  // The engine owns the inner element's classes and children; React only owns the outer wrapper.
  return (
    <div className={className} style={{ display: 'inline-flex', ...style }}>
      <div ref={hostRef} />
    </div>
  );
}
