// Example only: shows where the logo goes in the top bar. Adapt to the real header component and paths.
import { Link } from 'react-router-dom';                                       // or the router the app already uses
import IResolveLogo from '../components/brand/logo-motion/IResolveLogo.jsx';
import markUrl from '../assets/brand/iresolve-mark.png';

export default function TopBar({ children }) {
  return (
    <header style={{ height: 64, display: 'flex', alignItems: 'center', gap: 16, padding: '0 20px' }}>
      {/* Intro once per page load (not on route changes), spring spin every 10 s and on hover */}
      <Link to="/" aria-label="iResolve home" style={{ display: 'inline-flex', textDecoration: 'none' }}>
        <IResolveLogo variant="topbar" markSrc={markUrl} />
      </Link>

      {/* ...existing nav buttons, notifications, profile... */}
      {children}
    </header>
  );
}
