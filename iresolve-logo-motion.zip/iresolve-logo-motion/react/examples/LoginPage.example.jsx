// Example only: shows where the logo goes on the login page. Adapt to the real component and paths.
import IResolveLogo from '../components/brand/logo-motion/IResolveLogo.jsx';   // wherever you copied it
import markUrl from '../assets/brand/iresolve-mark.png';                       // the REAL mark (no text)

export default function LoginPage() {
  return (
    <main
      style={{
        minHeight: '100vh',
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        justifyContent: 'center',
        gap: 40,
        padding: '40px 20px',
      }}
    >
      {/* Full intro on every load/reload, then a spring spin every 7 s */}
      <IResolveLogo variant="login" markSrc={markUrl} />

      {/* ...the existing sign-in button / SSO redirect stays as it is... */}
    </main>
  );
}
