# Motion spec: iResolve Logo Motion v1.2

All numbers are the shipped defaults (`PRESETS` in `src/logoMotion.js`). Times are in milliseconds from page load unless noted. Angles are rotation around the vertical axis.

## 1. Login page intro (`variant: 'login'`), about 4.4 s

| Time (ms) | What happens | Easing |
|---|---|---|
| 0–180 | Mark fades in | linear |
| 0–1400 | Mark spins **2 full turns** (−720° → 0°) at the **centre of the lockup**. Starts at 940°/s, eases off, lands at 300°/s | cubic Hermite |
| 0–1100 | Mark scales 50% → 100% | ease-out cubic |
| 0–1300 | Mark tilts 20° → 0° (top towards the viewer) | ease-out cubic |
| 1400 → ~1900 | **Elastic landing**: the spring takes over at 300°/s, overshoots about 23° past the front, swings back, settles | spring ω₀ = 7 rad/s, ζ = 0.5 |
| 1400–2150 | Light sweep across the mark | sine in/out |
| 1800–2450 | Mark glides left into its resting place | ease-in-out cubic |
| 2250–3000 | "iResolve" slides out from behind the mark (fades in at the mark's edge) | ease-out cubic |
| 2650–3250 | Chrome line draws out from its centre | ease-in-out cubic |
| 2800–3550 | "By Credence" slides out from behind the mark | ease-out cubic |
| 3400–4400 | Shine runs along the chrome line | linear |
| 1400–4400 | Mark pauses facing front (after the elastic landing) while the text comes in | — |
| 4400 | First slow turn starts; the idle loop (section 3) runs from here | — |

The three text rows are centred under each other. The finished lockup (mark + text) is centred where the component is placed.

## 2. Top bar intro (`variant: 'topbar'`), about 2.75 s

| Time (ms) | What happens |
|---|---|
| 0–150 | Mark fades in |
| 0–1100 | Mark spins 2 turns **in place** (no glide): starts at 1100°/s, lands at 300°/s |
| 0–800 | Mark scales 60% → 100% |
| 1100 → ~1550 | Elastic landing: overshoots about 20°, springs back (ω₀ = 8 rad/s, ζ = 0.5) |
| 900–1550 | "iResolve" slides out from behind the mark |
| 1250–1750 | Chrome line draws out |
| 1350–1950 | "By Credence" slides out |
| 1950–2750 | Shine along the chrome line |
| 1100–2700 | Mark pauses facing front |
| 2700 | First slow turn; the idle loop (section 3) runs from here |

The intro plays **once per full page load** (`intro: 'once-per-load'`). Route changes and header re-mounts don't replay it.

## 3. Idle motion (both placements): pauses, slow turns, elastic fast spin

The loop, repeated for as long as the page is open:

```text
pause → slow turn → pause → slow turn → pause → ELASTIC FAST SPIN → pause → slow turn → …
```

Every pause lands **exactly on the front face**, so people can look at the logo. Nothing stops dead: each stop is a spring settle.

A damped spring chases a target angle:

```text
θ'' = k·(target − θ) + c·(targetSpeed − θ')        k = ω₀²,  c = 2·ζ·ω₀
```

- **Pause:** the target stands still at the front.
- **Slow turn:** the target moves round one turn on a cubic curve. It starts from rest, peaks, eases off, arrives at `slowLandVelocity` and stops. The spring tracks it closely, then overshoots slightly and settles: a soft, springy stop.
- **Fast spin:** the target pulls back (wind-up), then jumps a full turn ahead. Damping is measured against zero here, so it is a pure spring release: hard acceleration, about 16% overshoot, spring back.

| | Login | Top bar |
|---|---|---|
| Pause facing front | 2.2 s (~2.1–2.7 s within ±10° of front) | 2.8 s (~2.8–3.3 s) |
| Slow turn | 3.6 s, peaks ≈ 135°/s, arrives at 90°/s | 4.6 s, peaks ≈ 105°/s, arrives at 80°/s |
| Soft stop after a slow turn | overshoots ≈ 7°, springs back | ≈ 5–6° |
| Fast spin every | 2 slow turns | 2 slow turns (and on hover, 0.6 s cool-down) |
| Wind-up | −18° over 180 ms | −14° over 160 ms |
| Release | target jumps +378° over 140 ms | +374° over 130 ms |
| Spring | ω₀ = 7 rad/s, ζ = 0.5 | ω₀ = 8 rad/s, ζ = 0.5 |
| Fast-spin peak speed | ≈ 1350°/s (≈ 3.7 turns/s) | ≈ 1550°/s |
| Overshoot / swing back | ≈ 60° / ≈ −10°, then ≈ +2° | same |
| Pause after a fast spin | 2.8 s (includes the ~1.2 s settle) | 3.0 s |
| Light sweep | 750 ms from each fast-spin release | same |
| Full cycle | ≈ 15 s | ≈ 18 s |

`logo.spin()` and hover trigger a fast spin at any time. If that interrupts a slow turn, the fast spin is lengthened so it still lands on the front face, never on the back.

With `idle: { slowTurns: false }` the loop is just pause → elastic fast spin → pause. With `idle: false` the mark lands from the intro and stays still.

## 4. 3D construction

- **Front face:** the real mark image, untouched (pixel-identical at rest).
- **Back face:** the same image at the back. Seen from behind it is mirrored, like a solid object.
- **Edge:** evenly spaced slices of a 42%-darkened copy between front and back (≈1.2 slices per px of depth, 3–24).
- **Depth:** 6% of the mark width (login), 8% (top bar). **Perspective:** 5× the mark width.
- **Light sweep:** a 105° white gradient band, masked to the logo's alpha, crossing in 750 ms.

## 5. Acceptance checklist

- [ ] At rest, the front of the mark is pixel-identical to the real logo file (no tint, blur or re-drawing).
- [ ] While turning you can see **thickness** (a darker edge of the logo's own colours), not a flat card squashing.
- [ ] **Login:** every load/reload plays the full intro. The mark spins at the centre, glides left, and the text slides out from behind it. The three text rows end up centred under each other and the whole lockup is centred on the page.
- [ ] **Login:** after the intro: pause facing front (~2 s) → slow turn with a soft springy stop → pause → slow turn → pause → elastic fast spin (wind-up, whip, overshoot, spring back) → pause, and repeat. Every pause faces front, and nothing stops dead.
- [ ] **Top bar:** the intro plays on page load only (not on route changes). Then the same loop with ~3 s pauses, plus an elastic fast spin on hover. Nothing else in the bar moves or reflows.
- [ ] Light and dark themes both look right ("Resolve" is dark in light mode, chrome in dark mode).
- [ ] No console errors. No new npm dependencies. No network requests other than the mark image (and the app's own font files).
- [ ] Works in current Chrome, Edge, Firefox and Safari (macOS and iOS).
- [ ] The animation pauses when the tab is hidden or the logo is scrolled off-screen, and resumes smoothly.
