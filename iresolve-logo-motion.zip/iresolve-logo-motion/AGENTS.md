# Agent notes

This folder is **iResolve Logo Motion**: an animated 3D iResolve logo for the login page and the top bar.

1. Read `README.md` first: it has the integration steps, in order.
2. `MOTION_SPEC.md` is the source of truth for the motion and ends with the acceptance checklist.
3. Open `demo.html` to see the target behaviour. It uses a placeholder mark: the job is to use the **real** iResolve logo.

Hard rules:

- No new dependencies and no CDN or Google Fonts. The target server cannot install third-party software and must work offline.
- Configure the engine (`src/logoMotion.js`) through options and CSS variables. Don't rewrite it.
- The real logo must stay pixel-identical at rest.
- Don't touch authentication or SSO logic on the login page. Only the logo changes.
