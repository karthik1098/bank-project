# iResolve Logo Motion

An animated 3D iResolve logo for two places in the app:

| Placement | On page load | After that |
|---|---|---|
| **Login page** (big logo) | Full intro: the mark spins in at the centre, glides left, "iResolve" slides out from behind it, the chrome line draws out, "By Credence" slides in | A loop: **pause** facing front (~2 s, so people can look at the logo) → **slow turn** that eases out of the pause and glides into a soft springy stop → pause → slow turn → pause → **elastic fast spin** (winds back, whips round, overshoots, springs back) → repeat. It never stops dead: every stop is springy. |
| **Top bar** (small logo) | Compact intro: the mark spins in place, the text slides out | The same loop, calmer (longer pauses, slower turns). Hovering over the logo triggers an elastic fast spin. |

**Zero dependencies.** Plain JavaScript and CSS: no npm packages, no CDN, no build step, nothing loaded from the internet. It runs as-is on the locked-down Windows server.

Open **`demo.html`** in a browser to see both placements (switch with the tabs at the bottom). The demo uses a placeholder mark. The real logo replaces it.

> Opened straight from disk (`file://`), browsers block two small touches: the light sweep and the canvas-shaded edge (it falls back to a CSS-darkened edge). To see it exactly as it will look on the site, serve the folder, e.g. `python -m http.server 8000`, then open `http://localhost:8000/demo.html`.

---

## For the AI agent doing the integration (Claude / Codex)

**Goal:** put this into the iResolve frontend using the **real iResolve logo**, so that the login page and the top bar behave exactly like `demo.html`.

### Rules

- Don't add npm dependencies and don't load anything from a CDN or Google Fonts (the server can't install third-party software, and the app must work offline).
- Don't rewrite the engine. Configure it through options and CSS variables. `MOTION_SPEC.md` is the source of truth for the motion.
- Keep the real logo pixel-identical at rest. Don't recolour, re-draw or "improve" it.
- Work through the steps below in order and finish with the acceptance checklist in `MOTION_SPEC.md`.

### What's in this folder

```text
iresolve-logo-motion/
├── README.md                    ← you are here: integration steps
├── MOTION_SPEC.md               ← exact timings, spring settings, acceptance checklist
├── AGENTS.md / CLAUDE.md        ← pointers for coding agents
├── demo.html                    ← open in a browser: login page + top bar preview
├── src/
│   ├── logoMotion.js            ← the engine (zero dependencies, ~25 KB unminified)
│   └── logoMotion.css           ← styles; customise through --ilm-* variables
├── react/
│   ├── IResolveLogo.jsx         ← React wrapper (copy next to logoMotion.js/.css)
│   └── examples/                ← LoginPage / TopBar usage examples
├── assets/
│   └── iresolve-mark-placeholder.png   ← placeholder: replace with the real mark
└── tools/
    └── split_logo.py            ← cuts the real logo into mark / wordmark / tagline (needs Pillow)
```

### Step 1: Prepare the real logo (the most important step)

The engine needs **the mark only**: the red i, the silver building and the red swoosh, with **no text**, a **transparent background**, and **tightly cropped**.

1. Find the real logo file (ask the owner, or look in the repo, e.g. `static/`, `public/`, `src/assets/`).
2. Pick the matching case:
   - **You already have a separate mark** with a transparent background: use it as-is. If it has lots of empty padding, run `python tools/split_logo.py path/to/mark.png --mark-only`.
   - **You only have the full lockup** (mark + "iResolve" + chrome line + "By Credence"): run `python tools/split_logo.py path/to/full-logo.png`. It writes `brand-out/iresolve-mark.png` and, if it finds them, `iresolve-wordmark.png`, `iresolve-line.png` and `iresolve-tagline.png`.
   - **The logo has a white or coloured background** (JPG, etc.): the tool removes it automatically (`--bg auto`, or force it with `--bg "#ffffff"`).
3. **Open `brand-out/split-preview.png` and check the boxes**: red = mark, blue = wordmark, green = tagline, orange = line. If a box is wrong, crop the mark by hand instead.
4. Recommended mark file: PNG or WebP, 512–1024 px on its long side, transparent background. SVG works too.
5. Put it in the frontend, e.g. `src/assets/brand/iresolve-mark.png`, so it is served **from the same origin** as the app. (A cross-origin image still works, but the edge shading falls back to a CSS filter.)

The wordmark and tagline are **live text** by default ("iResolve" with a red i, the chrome line, "By Credence"). Live text is sharp at any size and follows the dark theme. If the real lettering must match the logo file exactly, pass the cropped images as `wordmarkSrc` and `taglineSrc` (see Options).

### Step 2: Add the engine to the frontend

Copy these three files into one folder in the frontend, for example `src/components/brand/logo-motion/`:

- `src/logoMotion.js`
- `src/logoMotion.css`
- `react/IResolveLogo.jsx`

`IResolveLogo.jsx` imports `./logoMotion.js` and `./logoMotion.css`, so keep the three files together. If you split them up, fix the imports.

### Step 3: Login page

```jsx
import IResolveLogo from '../components/brand/logo-motion/IResolveLogo.jsx';
import markUrl from '../assets/brand/iresolve-mark.png';

<IResolveLogo variant="login" markSrc={markUrl} />
```

- Replace the current big logo with it, centred above the sign-in button / SSO action. Don't touch the authentication logic.
- The full intro plays on every load and reload of the page (`intro: 'once-per-load'` resets on each full page load).
- The lockup sizes itself responsively: the mark is `clamp(140px, 30vw, 220px)`. To change it, override `--ilm-mark` (see Theming).

### Step 4: Top bar

```jsx
<Link to="/" aria-label="iResolve home">
  <IResolveLogo variant="topbar" markSrc={markUrl} />
</Link>
```

- Replace the current top-bar logo (left side). It's designed for a 56–72 px bar: the mark is 40 px, "iResolve" is 21 px, "By Credence" is 7.5 px.
- The intro plays **once per page load**, not on every route change, even if the header re-mounts.
- Hovering over the logo triggers an elastic fast spin.
- Make sure no parent clips it with a tight `overflow: hidden`: while turning, the mark briefly extends about 10% beyond its box.
- Nothing else in the bar moves. The logo reserves its final size from the first frame (no layout shift).

### Step 5: Theme

- Dark mode follows `<html data-theme="dark">` or `<html class="dark">`. If iResolve marks dark mode differently, add that selector to the dark block at the top of `logoMotion.css`, or put `data-ilm-theme="dark"` on the logo element.
- Colours and sizes are CSS variables on `.ilm`, `.ilm--login` and `.ilm--topbar`:

| Variable | Default | What it controls |
|---|---|---|
| `--ilm-mark` | login `clamp(140px,30vw,220px)`, top bar `40px` | mark width |
| `--ilm-word-size` | login `clamp(34px,8vw,68px)`, top bar `21px` | "iResolve" size |
| `--ilm-tag-size` | login `clamp(11px,2.2vw,15px)`, top bar `7.5px` | "By Credence" size |
| `--ilm-gap` | login `clamp(10px,2vw,20px)`, top bar `9px` | space between mark and text |
| `--ilm-accent` | `#d21f2b` | the red "i" |
| `--ilm-ink` / `--ilm-muted` | warm black / grey (light), off-white / sand (dark) | "Credence" / "By" |
| `--ilm-word-fill` | dark gradient (light), chrome gradient (dark) | "Resolve" |
| `--ilm-chrome` | silver gradient | the chrome line |
| `--ilm-font` | `inherit` | wordmark font |
| `--ilm-shadow` | soft drop shadow on the login mark | set `none` to remove |

### Step 6: Fonts

The wordmark uses the app's font (`--ilm-font: inherit`). The demo uses Montserrat 800 from Google Fonts, which is fine for the preview but **not for the server**. Either keep the app font or self-host Montserrat (add the woff2 files to the frontend and set `--ilm-font: 'Montserrat', sans-serif`).

---

## Options

Pass options as props to `<IResolveLogo>`, or as the second argument of `IResolveLogoMotion.mount(element, options)`.

| Option | Default | Notes |
|---|---|---|
| `variant` | `'login'` | `'login'` or `'topbar'` |
| `markSrc` | **required** | URL of the mark image (no text, transparent) |
| `intro` | `'once-per-load'` | `'once-per-load'` · `'every-mount'` · `'never'` |
| `idle` | preset | Object to tweak the idle motion (below), or `false` for no idle motion |
| `wordText` | `'iResolve'` | Live wordmark; the first letter uses `--ilm-accent` |
| `taglineHTML` | `'By <b>Credence</b>'` | Trusted markup only |
| `wordmarkSrc` / `taglineSrc` | `null` | Images to use instead of the live text |
| `showText` / `showLine` / `showTagline` | `true` | Hide parts of the lockup |
| `respectReducedMotion` | `false` | **Off on purpose**: the owner wants the motion on every device. Set `true` if accessibility policy requires honouring the OS "reduce motion" setting |
| `speed` | `1` | `0.4` = slow motion (handy for reviews) |
| `ariaLabel` | `'iResolve by Credence'` | |
| `layers` | auto | Number of edge slices (≈1 per px of depth) |
| `onReady(logo)` / `onIntroEnd(logo)` / `onSpin(logo)` | | Callbacks receive the controller |

`idle` settings (defaults are in `PRESETS` in `logoMotion.js`; details in `MOTION_SPEC.md`):

| Key | Login | Top bar | Meaning |
|---|---|---|---|
| `pause` | `2200` | `2800` | ms facing front between moves (includes the ~0.6 s soft settle) |
| `slowTurns` | `true` | `true` | Slow turns between the pauses. `false` = pauses and elastic fast spins only |
| `slowTurn` | `3600` | `4600` | ms for one slow turn |
| `slowLandVelocity` | `90` | `80` | °/s the slow turn arrives with: bigger = a more visible spring-back at each stop |
| `fastAfterTurns` | `2` | `2` | Elastic fast spin after this many slow turns (`0` = only on hover / `logo.spin()`) |
| `turns` | `1` | `1` | Full turns per fast spin |
| `windup` / `windupDur` | `18°` / `180 ms` | `14°` / `160 ms` | Pull-back before the fast spin |
| `stiffness` | `7` | `8` | Spring frequency (rad/s): higher = snappier |
| `damping` | `0.5` | `0.5` | 0.35 very elastic · 0.5 elastic · 0.7 firm |
| `fastPause` | `2800` | `3000` | ms pause after a fast spin (includes its ~1.2 s spring settle) |
| `startAfter` | `3000` | `1600` | ms after the intro lands before the first move |
| `hover` | `false` | `true` | Elastic fast spin on mouse hover |

Example: longer pauses and no hover spin in the top bar:

```jsx
<IResolveLogo variant="topbar" markSrc={markUrl} idle={{ pause: 4000, hover: false }} />
```

### Controller

`onReady={(logo) => ...}` gives you:

- `logo.replay()`: play the intro again
- `logo.spin()`: elastic fast spin now
- `logo.setSpeed(x)`: change the playback speed
- `logo.destroy()`: stop everything and clean up (the React wrapper does this on unmount)

---

## Plain HTML or a Django template

If the login page is server-rendered instead of React:

```html
{% load static %}
<link rel="stylesheet" href="{% static 'brand/logo-motion/logoMotion.css' %}">

<div data-ilm-variant="login" data-ilm-src="{% static 'brand/iresolve-mark.png' %}"></div>

<script src="{% static 'brand/logo-motion/logoMotion.js' %}"></script>
```

Elements with `data-ilm-src` mount automatically when the DOM is ready (`data-ilm-variant="topbar"` for the bar). For full control, call `IResolveLogoMotion.mount(element, options)` yourself.

---

## How it works (short)

- **3D from a flat image:** the logo image is stacked into thin slices along the Z axis. The front face is the untouched logo, the back face is the logo again (mirrored when seen from behind, like a solid object), and between them sit slices of a 42%-darker copy that form the edge. When the mark turns you see real thickness instead of a flat card squashing.
- **Motion:** the intro spin is a cubic curve that starts fast and lands at a set speed. From the landing on, the mark is driven by a **damped spring that chases a target angle**. During a pause the target stands still. For a slow turn it moves smoothly round one turn and stops, so the mark glides in and settles with a small spring-back. For a fast spin it winds back and then jumps a full turn ahead. Because the spring is under-damped, the mark accelerates hard, overshoots and springs back: that is the elastic feel. Every pause lands exactly on the front face.
- **Light sweep:** a highlight crosses the mark (masked to the logo's shape) on each landing.
- **Cost:** only `transform` and `opacity` change, on the GPU. The animation loop pauses while the tab is hidden or the logo is scrolled off-screen.

## Troubleshooting

| Symptom | Fix |
|---|---|
| Nothing animates | Check the console for `could not load markSrc`. Check `respectReducedMotion` isn't `true` on a device with "reduce motion" on. |
| Spinning mark looks like a box or card | The mark PNG has a solid background. Run `tools/split_logo.py`. |
| Edge looks grey or flat instead of a darker version of the logo | The image is cross-origin without CORS, so the canvas fallback kicked in. Serve the mark from the app's own origin. |
| Text slides from the wrong place or is clipped | The component was mounted while hidden (`display: none`). Mount it when visible, or call `logo.replay()` once it's shown. |
| Intro doesn't replay when navigating between pages | By design (`once-per-load`). Use `intro="every-mount"` if you want it on every mount. |
| Intro never shows in development | It does: React StrictMode's double mount is handled. Check that `markSrc` resolves. |
| Top bar logo is cut off while turning | A parent has `overflow: hidden` too close to the logo. Give it a few px of room. |
