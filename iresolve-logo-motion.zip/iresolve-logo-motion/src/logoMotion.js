/*!
 * iResolve Logo Motion v1.2.0
 * Animated 3D logo for the iResolve login page and top bar.
 * Zero dependencies, no CDN, no build step. Works with any transparent PNG / WebP / SVG logo mark.
 *
 *   IResolveLogoMotion.mount(element, { variant: 'login' | 'topbar', markSrc: '/path/to/iresolve-mark.png' })
 *
 * Motion: intro on load -> a loop of brief pauses (facing front, so people can look at the logo) and slow
 * turns that glide into a soft springy stop; every couple of turns the slow turn is replaced by an elastic
 * fast spin that winds back, whips round, overshoots and springs back. Driven by a damped spring that
 * chases a target angle.
 *
 * 3D: the flat logo image is stacked into thin slices along the Z axis (a darkened copy forms the edge),
 * so when it turns you see real thickness. At rest the front face is the untouched logo file.
 *
 * Read README.md and MOTION_SPEC.md before changing timings.
 */
(function (root) {
  'use strict';

  var VERSION = '1.2.0';
  var playedThisLoad = {};            // intro: 'once-per-load' bookkeeping (resets on every full page load)

  /* --------------------------------------------------------------------------------------------
     PRESETS  (ms unless noted, angles in degrees, velocities in degrees/second)
     -------------------------------------------------------------------------------------------- */
  var PRESETS = {
    login: {
      glide: true,                   // mark spins at the centre of the lockup, then glides left
      depthRatio: 0.06,              // extrusion depth = 6% of the mark width (keep in sync with CSS)
      intro: {
        spin: { turns: 2, duration: 1400, startVelocity: 940, landVelocity: 300 },
        fade: 180, scaleFrom: 0.5, scaleDur: 1100, tiltFrom: 20, tiltDur: 1300,
        glide: [1800, 2450],         // mark glides from the centre to its resting place
        word:  [2250, 3000],         // "iResolve" slides out from behind the mark
        line:  [2650, 3250],         // chrome line draws out from its centre
        tag:   [2800, 3550],         // "By Credence" slides out
        shine: [3400, 4400],         // light runs along the chrome line
        end: 4400
      },
      idle: {
        enabled: true,
        pause: 2200,                 // facing front between moves, so people can look at the logo (incl. ~0.6 s soft settle)
        slowTurns: true,             // slow turns between the pauses (false = pauses + fast spins only)
        slowTurn: 3600,              // one slow turn: eases out of the pause, glides into a soft springy stop
        slowLandVelocity: 90,        // deg/s it arrives with -> size of the gentle spring-back at each stop
        fastAfterTurns: 2,           // elastic fast spin after this many slow turns (0 = only on hover / logo.spin())
        turns: 1,                    // full turns per fast spin
        windup: 18, windupDur: 180,  // spring-loading: pull back this many degrees first
        ramp: 140,                   // how fast the spin target jumps forward
        stiffness: 7,                // spring natural frequency (rad/s): higher = snappier
        damping: 0.5,                // 0.35 very elastic .. 0.5 elastic .. 0.7 firm
        fastPause: 2800,             // pause after a fast spin (includes its ~1.2 s spring settle)
        startAfter: 3000,            // after the intro lands, pause this long before the first move
        hover: false
      }
    },
    topbar: {
      glide: false,                  // the bar logo spins in place
      depthRatio: 0.08,
      intro: {
        spin: { turns: 2, duration: 1100, startVelocity: 1100, landVelocity: 300 },
        fade: 150, scaleFrom: 0.6, scaleDur: 800, tiltFrom: 0, tiltDur: 1,
        glide: null,
        word:  [900, 1550],
        line:  [1250, 1750],
        tag:   [1350, 1950],
        shine: [1950, 2750],
        end: 2750
      },
      idle: {
        enabled: true, pause: 2800, slowTurns: true, slowTurn: 4600, slowLandVelocity: 80, fastAfterTurns: 2,
        turns: 1, windup: 14, windupDur: 160, ramp: 130, stiffness: 8, damping: 0.5,
        fastPause: 3000, startAfter: 1600, hover: true
      }
    }
  };

  var GLINT_MS = 750;                // light sweep across the mark during each fast spin
  var SUBSTEP = 1 / 240;             // s: physics step
  var FOREVER = 1e9;                 // ms: a hold that never ends (idle motion switched off)

  var DEFAULTS = {
    variant: 'login',
    markSrc: null,                   // REQUIRED: the logo mark only (no text), transparent background
    wordText: 'iResolve',            // live-text wordmark; first letter gets the accent colour
    accentFirstLetter: true,
    wordmarkSrc: null,               // optional image to use instead of live wordmark text
    taglineHTML: 'By <b>Credence</b>',  // trusted markup only (never user input)
    taglineSrc: null,                // optional image to use instead of live tagline text
    showText: true, showLine: true, showTagline: true,
    intro: 'once-per-load',          // 'once-per-load' | 'every-mount' | 'never'
    introKey: null,                  // defaults to the variant name
    idle: {},                        // overrides for the preset idle settings, or false for no idle motion
    speed: 1,                        // 0.4 = slow motion (demo), 1 = normal
    respectReducedMotion: false,     // true = no motion when the OS "reduce motion" setting is on
    layers: null,                    // number of edge slices (default ~1 per px of depth)
    ariaLabel: 'iResolve by Credence',
    onReady: null, onIntroEnd: null, onSpin: null
  };

  /* -------------------------------------------- helpers ------------------------------------------- */
  function clamp01(x) { return x < 0 ? 0 : x > 1 ? 1 : x; }
  function seg(t, a, b) { return clamp01((t - a) / (b - a)); }
  function easeOutCubic(t) { return 1 - Math.pow(1 - t, 3); }
  function easeInOutCubic(t) { return t < 0.5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2; }
  function easeInOutSine(t) { return 0.5 - 0.5 * Math.cos(Math.PI * clamp01(t)); }
  function isObj(v) { return v !== null && typeof v === 'object' && !Array.isArray(v); }
  function merge(base, over) {
    var out = {}, k;
    for (k in base) out[k] = isObj(base[k]) ? merge(base[k], null) : base[k];
    if (over) for (k in over) {
      if (over[k] === undefined) continue;
      out[k] = isObj(over[k]) && isObj(base[k]) ? merge(base[k], over[k]) : over[k];
    }
    return out;
  }
  function escapeHTML(s) {
    return String(s).replace(/[&<>"']/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
    });
  }
  function make(tag, cls, parent) {
    var e = document.createElement(tag);
    if (cls) e.className = cls;
    if (parent) parent.appendChild(e);
    return e;
  }
  function now() { return root.performance && root.performance.now ? root.performance.now() : Date.now(); }

  /* Intro spin: cubic Hermite from -360*turns at startVelocity to 0 at landVelocity (deg, deg/s, ms).
     When it lands, the spring takes over with that velocity, so the landing is elastic too. */
  function introSpinAngle(sp, cfg) {
    var T = cfg.duration / 1000, D = 360 * cfg.turns, s = clamp01(sp / cfg.duration), s2 = s * s, s3 = s2 * s;
    return -D + D * (3 * s2 - 2 * s3) + T * cfg.startVelocity * (s3 - 2 * s2 + s) + T * cfg.landVelocity * (s3 - s2);
  }

  /* --------------------------------------------------------------------------------------------
     MOUNT
     -------------------------------------------------------------------------------------------- */
  function mount(host, options) {
    if (!host || !host.appendChild) throw new Error('IResolveLogoMotion.mount: pass the element to render into');
    var o = merge(DEFAULTS, options || {});
    if (!o.markSrc) throw new Error('IResolveLogoMotion.mount: markSrc (the logo mark image) is required');
    var preset = PRESETS[o.variant];
    if (!preset) throw new Error('IResolveLogoMotion.mount: unknown variant "' + o.variant + '"');
    var intro = preset.intro;
    var cfg = o.idle === false ? merge(preset.idle, { enabled: false }) : merge(preset.idle, o.idle);
    var introMode = o.intro, introKey = o.introKey || o.variant;
    var reduce = !!(o.respectReducedMotion && root.matchMedia &&
                    root.matchMedia('(prefers-reduced-motion: reduce)').matches);

    host.classList.add('ilm', 'ilm--' + o.variant);
    host.innerHTML = '';
    host.setAttribute('role', 'img');
    host.setAttribute('aria-label', o.ariaLabel);

    /* ---- DOM ---- */
    var markEl = make('div', 'ilm-mark', host);
    var spinEl = make('div', 'ilm-spin', markEl);
    var glintEl = null, wordClip = null, wordEl = null, lineEl = null, shineEl = null, tagClip = null, tagEl = null;
    if (o.showText) {
      var textEl = make('div', 'ilm-text', host);
      textEl.setAttribute('aria-hidden', 'true');
      wordClip = make('div', 'ilm-clip', textEl);
      wordEl = make('div', 'ilm-slide ilm-word', wordClip);
      if (o.wordmarkSrc) {
        var wi = make('img', 'ilm-word-img', wordEl); wi.alt = ''; wi.src = o.wordmarkSrc;
        wi.addEventListener('load', measure);
      } else {
        var wt = String(o.wordText);
        wordEl.innerHTML = o.accentFirstLetter && wt.length > 1
          ? '<span class="ilm-i">' + escapeHTML(wt.charAt(0)) + '</span><span class="ilm-rest">' + escapeHTML(wt.slice(1)) + '</span>'
          : '<span class="ilm-rest">' + escapeHTML(wt) + '</span>';
      }
      if (o.showLine) { lineEl = make('div', 'ilm-chrome', textEl); shineEl = make('span', 'ilm-shine', lineEl); }
      if (o.showTagline) {
        tagClip = make('div', 'ilm-clip', textEl);
        tagEl = make('div', 'ilm-slide ilm-tag', tagClip);
        if (o.taglineSrc) {
          var ti = make('img', 'ilm-tag-img', tagEl); ti.alt = ''; ti.src = o.taglineSrc;
          ti.addEventListener('load', measure);
        } else {
          tagEl.innerHTML = o.taglineHTML;
        }
      }
    }

    /* ---- state ---- */
    var st = {
      destroyed: false, raf: 0, visible: true, speed: o.speed > 0 ? o.speed : 1, lastT: null,
      introT0: null, introSpinning: false, glintT0: null, shift: 0, dw: 0, db: 0
    };

    function setSpin(angle, tilt, scale) {
      spinEl.style.transform = 'rotateX(' + tilt.toFixed(2) + 'deg) rotateY(' + angle.toFixed(2) + 'deg) scale(' + scale.toFixed(4) + ')';
    }

    function measure() {
      if (st.destroyed) return;
      var pm = markEl.style.transform, pw = wordEl ? wordEl.style.transform : '', pt = tagEl ? tagEl.style.transform : '';
      markEl.style.transform = 'none';
      if (wordEl) wordEl.style.transform = 'none';
      if (tagEl) tagEl.style.transform = 'none';
      var h = host.getBoundingClientRect(), m = markEl.getBoundingClientRect();
      st.shift = (h.left + h.width / 2) - (m.left + m.width / 2);
      if (wordEl) st.dw = wordEl.getBoundingClientRect().right - wordClip.getBoundingClientRect().left + 4;
      if (tagEl) st.db = tagEl.getBoundingClientRect().right - tagClip.getBoundingClientRect().left + 4;
      markEl.style.transform = pm;
      if (wordEl) wordEl.style.transform = pw;
      if (tagEl) tagEl.style.transform = pt;
    }

    function applyIntro(t) {
      markEl.style.opacity = seg(t, 0, intro.fade).toFixed(3);
      if (preset.glide && intro.glide) {
        markEl.style.transform = 'translateX(' + (st.shift * (1 - easeInOutCubic(seg(t, intro.glide[0], intro.glide[1])))).toFixed(2) + 'px)';
      }
      if (wordEl) wordEl.style.transform = 'translateX(' + (-st.dw * (1 - easeOutCubic(seg(t, intro.word[0], intro.word[1])))).toFixed(2) + 'px)';
      if (lineEl) lineEl.style.transform = 'scaleX(' + easeInOutCubic(seg(t, intro.line[0], intro.line[1])).toFixed(4) + ')';
      if (tagEl) tagEl.style.transform = 'translateX(' + (-st.db * (1 - easeOutCubic(seg(t, intro.tag[0], intro.tag[1])))).toFixed(2) + 'px)';
      if (shineEl) shineEl.style.transform = 'translateX(' + (-120 + 620 * seg(t, intro.shine[0], intro.shine[1])).toFixed(1) + '%)';
    }

    function showFinalText() {
      markEl.style.opacity = '1';
      markEl.style.transform = 'none';
      if (wordEl) wordEl.style.transform = 'none';
      if (tagEl) tagEl.style.transform = 'none';
      if (lineEl) lineEl.style.transform = 'none';
      if (shineEl) shineEl.style.transform = 'translateX(-120%)';
    }

    /* ---------------- spring physics ----------------
       target = base + offset of the current move   (degrees)
       a = k (target - th) + c (refVelocity - v)
       moves: hold (still) -> slow turn (Hermite: from rest to slowLandVelocity, then the target stops and the
       spring settles softly) -> hold -> ... -> fast spin (wind-up, then the target jumps a full turn; pure
       spring release: hard acceleration, ~16% overshoot, spring back) -> hold ...                       */
    var ph = { on: false, simT: 0, th: 0, v: 0, base: 0, seg: null, slowCount: 0, lastFastEnd: -10 };

    function hold(ms) { ph.seg = { type: 'hold', t0: ph.simT, dur: ms / 1000 }; }
    function startSlow() {
      ph.seg = { type: 'slow', t0: ph.simT, T: Math.max(0.3, cfg.slowTurn / 1000), v1: cfg.slowLandVelocity };
    }
    function startFast(total) {
      ph.seg = { type: 'fast', t0: ph.simT, total: total, windup: cfg.windup,
                 windupS: Math.max(0.001, cfg.windupDur / 1000), rampS: Math.max(0.001, cfg.ramp / 1000) };
      ph.slowCount = 0;
      if (o.onSpin) o.onSpin(api);
    }
    function slowOffset(sg, u) { var u2 = u * u, u3 = u2 * u; return 360 * (3 * u2 - 2 * u3) + sg.T * sg.v1 * (u3 - u2); }
    function slowVelocity(sg, u) { var u2 = u * u; return (360 * (6 * u - 6 * u2) + sg.T * sg.v1 * (3 * u2 - 2 * u)) / sg.T; }

    function segOffset() {
      var sg = ph.seg;
      if (!sg) return 0;
      if (sg.type === 'slow') return slowOffset(sg, clamp01((ph.simT - sg.t0) / sg.T));
      if (sg.type === 'fast') {
        var u = ph.simT - sg.t0;
        if (u < sg.windupS) return -sg.windup * easeInOutSine(u / sg.windupS);
        if (u < sg.windupS + sg.rampS) return -sg.windup + (sg.total + sg.windup) * easeInOutSine((u - sg.windupS) / sg.rampS);
        return sg.total;
      }
      return 0;
    }
    function target() { return ph.base + segOffset(); }
    function refVelocity() {
      var sg = ph.seg;
      return sg && sg.type === 'slow' ? slowVelocity(sg, clamp01((ph.simT - sg.t0) / sg.T)) : 0;
    }

    function nextMove() {
      if (!cfg.enabled || reduce) { hold(FOREVER); return; }
      if (!cfg.slowTurns || (cfg.fastAfterTurns > 0 && ph.slowCount >= cfg.fastAfterTurns)) startFast(360 * cfg.turns);
      else startSlow();
    }

    function advance() {
      var sg = ph.seg, u = ph.simT - sg.t0;
      if (sg.type === 'hold') {
        if (u >= sg.dur) nextMove();
      } else if (sg.type === 'slow') {
        if (u >= sg.T) { ph.base += 360; ph.slowCount++; hold(cfg.pause); }
      } else if (u >= sg.windupS + sg.rampS) {           // fast spin released: fold it into the base
        ph.base += sg.total;
        ph.lastFastEnd = ph.simT;
        hold(cfg.fastPause);
        st.glintT0 = now() - 1;                         // light sweep while it overshoots and springs back
      }
    }

    function startPhysics(angle, velocity, holdMs) {
      ph.on = true; ph.th = angle; ph.v = velocity; ph.base = 0; ph.slowCount = 0;
      hold(cfg.enabled && !reduce ? holdMs : FOREVER);
    }

    function stepPhysics(dt) {
      if (!(dt > 0)) return ph.th;
      var n = Math.max(1, Math.ceil(dt / SUBSTEP)), h = dt / n;
      var k = cfg.stiffness * cfg.stiffness, c = 2 * cfg.damping * cfg.stiffness;
      for (var i = 0; i < n; i++) {
        ph.simT += h;
        advance();
        var a = k * (target() - ph.th) + c * (refVelocity() - ph.v);
        ph.v += a * h;
        ph.th += ph.v * h;
      }
      if (ph.th > 7200) { ph.th -= 7200; ph.base -= 7200; }
      return ph.th;
    }

    function physicsResting() {
      return !!ph.seg && ph.seg.type === 'hold' && ph.seg.dur >= FOREVER / 1000 &&
             Math.abs(target() - ph.th) < 0.05 && Math.abs(ph.v) < 0.5;
    }

    /* hover / logo.spin(): elastic fast spin now (lands on the front face, never on the back) */
    function requestFast() {
      if (!ph.on || !ph.seg || !cfg.enabled || reduce) return false;
      if (ph.seg.type === 'fast' || ph.simT - ph.lastFastEnd < 0.6) return false;
      var total = 360 * cfg.turns;
      if (ph.seg.type === 'slow') {
        var off = slowOffset(ph.seg, clamp01((ph.simT - ph.seg.t0) / ph.seg.T));
        ph.base += off;
        total += 360 - off;
      }
      startFast(total);
      kick();
      return true;
    }

    /* ---------------- frame loop ---------------- */
    function frame() {
      st.raf = 0;
      if (st.destroyed) return;
      var t = now();
      var dt = st.lastT === null ? 0 : Math.min(0.05, (t - st.lastT) / 1000) * st.speed;
      st.lastT = t;
      var busy = false, angle = 0, tilt = 0, sc = 1;

      if (st.introT0 !== null) {
        var it = (t - st.introT0) * st.speed;
        applyIntro(it);
        if (st.introSpinning) {
          if (it < intro.spin.duration) {
            angle = introSpinAngle(it, intro.spin);
            sc = intro.scaleFrom + (1 - intro.scaleFrom) * easeOutCubic(seg(it, 0, intro.scaleDur));
            tilt = intro.tiltFrom * (1 - easeOutCubic(seg(it, 0, intro.tiltDur)));
          } else {
            st.introSpinning = false;
            st.glintT0 = t;
            startPhysics(0, intro.spin.landVelocity, cfg.startAfter);   // elastic landing, pause, then the idle loop
          }
        }
        if (it < intro.end) busy = true;
        else { st.introT0 = null; finishIntro(); }
      }

      if (ph.on && !st.introSpinning) {
        angle = stepPhysics(dt);
        if (!physicsResting()) busy = true;
      }
      setSpin(angle, tilt, sc);

      if (st.glintT0 !== null && glintEl) {
        var g = (t - st.glintT0) * st.speed / GLINT_MS;
        if (g >= 1) { glintEl.style.opacity = '0'; st.glintT0 = null; }
        else {
          glintEl.style.opacity = Math.sin(Math.PI * clamp01(g)).toFixed(3);
          glintEl.style.backgroundPosition = (130 - 160 * clamp01(g)).toFixed(1) + '% 0';
          busy = true;
        }
      } else if (st.glintT0 !== null) st.glintT0 = null;

      if (busy && st.visible && !document.hidden) st.raf = root.requestAnimationFrame(frame);
      else st.lastT = null;
    }
    function kick() {
      if (st.raf || st.destroyed) return;
      st.lastT = null;
      st.raf = root.requestAnimationFrame(frame);
    }

    function playIntro() {
      measure();
      ph.on = false;
      st.introT0 = now();
      st.introSpinning = true;
      st.glintT0 = null;
      if (glintEl) glintEl.style.opacity = '0';
      applyIntro(0);
      setSpin(-360 * intro.spin.turns, intro.tiltFrom, intro.scaleFrom);
      kick();
    }

    function finishIntro() {
      showFinalText();
      if (introMode === 'once-per-load') playedThisLoad[introKey] = true;
      if (o.onIntroEnd) o.onIntroEnd(api);
    }

    /* ---- events ---- */
    function onEnter() { if (cfg.hover) requestFast(); }
    function onResize() { measure(); }
    function onVisibility() { if (!document.hidden) kick(); }
    host.addEventListener('mouseenter', onEnter);
    root.addEventListener('resize', onResize);
    document.addEventListener('visibilitychange', onVisibility);
    var io = null;
    if (root.IntersectionObserver) {
      io = new root.IntersectionObserver(function (entries) {
        st.visible = entries[entries.length - 1].isIntersecting;
        if (st.visible) kick();
      });
      io.observe(host);
    }

    /* ---- 3D layers from the logo image ---- */
    function makeEdgeSrc(image) {
      try {
        var iw = image.naturalWidth || 256, ih = image.naturalHeight || iw;
        var w = Math.min(iw, 512), h = Math.max(1, Math.round(w * ih / iw));
        var c = document.createElement('canvas'); c.width = w; c.height = h;
        var x = c.getContext('2d');
        x.drawImage(image, 0, 0, w, h);
        x.globalCompositeOperation = 'source-atop';
        x.fillStyle = 'rgba(0,0,0,0.42)';
        x.fillRect(0, 0, w, h);
        return c.toDataURL('image/png');       // throws if the image is cross-origin without CORS
      } catch (e) { return null; }
    }

    function addLayer(src, cls, f) {
      var e = make('img', 'ilm-layer ' + cls, spinEl);
      e.alt = ''; e.draggable = false; e.decoding = 'async'; e.src = src;
      e.style.transform = 'translateZ(calc(var(--ilm-depth) * ' + f.toFixed(4) + '))';
      return e;
    }

    function buildLayers(image) {
      var wpx = markEl.getBoundingClientRect().width || 100;
      var depth = Math.max(2, wpx * preset.depthRatio);
      var slices = o.layers !== null && o.layers !== undefined ? Math.max(1, o.layers | 0)
                 : Math.max(3, Math.min(24, Math.round(depth * 1.2)));
      var edge = makeEdgeSrc(image);
      addLayer(o.markSrc, 'ilm-face', -0.5);                    // back face (mirrored from behind, like a solid object)
      for (var i = 1; i <= slices; i++) {
        var l = addLayer(edge || o.markSrc, 'ilm-edge', -0.5 + i / (slices + 1));
        if (!edge) l.style.filter = 'brightness(.55) saturate(1.15)';
      }
      addLayer(o.markSrc, 'ilm-face', 0.5);                     // front face: the real logo, untouched
      if (root.location && root.location.protocol === 'file:') return;   // browsers block CSS masks on file:// pages
      glintEl = make('div', 'ilm-glint', spinEl);
      var url = 'url(' + JSON.stringify(String(o.markSrc)) + ')';
      glintEl.style.webkitMaskImage = url;
      glintEl.style.maskImage = url;
    }

    function start() {
      var skip = reduce || introMode === 'never' || (introMode === 'once-per-load' && playedThisLoad[introKey]);
      if (skip) {
        showFinalText();
        setSpin(0, 0, 1);
        startPhysics(0, 0, Math.min(cfg.startAfter, cfg.pause)); kick();
      } else playIntro();
      if (document.fonts && document.fonts.ready) {
        document.fonts.ready.then(function () { if (!st.destroyed) measure(); });
      }
      if (o.onReady) o.onReady(api);
    }

    var api = {
      element: host,
      version: VERSION,
      replay: function () { if (!st.destroyed) playIntro(); },
      spin: function () { return requestFast(); },           // elastic fast spin now
      setSpeed: function (s) { st.speed = s > 0 ? s : 1; },
      destroy: function () {
        if (st.destroyed) return;
        st.destroyed = true;
        if (st.raf) root.cancelAnimationFrame(st.raf);
        root.removeEventListener('resize', onResize);
        document.removeEventListener('visibilitychange', onVisibility);
        host.removeEventListener('mouseenter', onEnter);
        if (io) io.disconnect();
        host.innerHTML = '';
        host.classList.remove('ilm', 'ilm--' + o.variant);
        host.style.removeProperty('--ilm-aspect');
      }
    };

    var img = new Image();
    img.decoding = 'async';
    img.onload = function () {
      if (st.destroyed) return;
      if (img.naturalWidth && img.naturalHeight) host.style.setProperty('--ilm-aspect', String(img.naturalWidth / img.naturalHeight));
      buildLayers(img);
      start();
    };
    img.onerror = function () {
      if (st.destroyed) return;
      if (root.console) root.console.warn('IResolveLogoMotion: could not load markSrc "' + o.markSrc + '"');
      showFinalText();
    };
    img.src = o.markSrc;

    return api;
  }

  /* Plain-HTML / Django-template convenience:
       <div data-ilm-variant="login" data-ilm-src="/static/brand/iresolve-mark.png"></div>
     is mounted automatically once the DOM is ready. */
  function autoMount(scope) {
    var els = (scope || document).querySelectorAll('[data-ilm-src]:not([data-ilm-mounted])');
    var apis = [];
    for (var i = 0; i < els.length; i++) {
      var el = els[i];
      el.setAttribute('data-ilm-mounted', '');
      apis.push(mount(el, {
        variant: el.getAttribute('data-ilm-variant') || 'login',
        markSrc: el.getAttribute('data-ilm-src'),
        intro: el.getAttribute('data-ilm-intro') || undefined
      }));
    }
    return apis;
  }
  if (typeof document !== 'undefined') {
    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', function () { autoMount(); });
    else autoMount();
  }

  root.IResolveLogoMotion = { mount: mount, autoMount: autoMount, presets: PRESETS, version: VERSION };
})(typeof window !== 'undefined' ? window : this);
