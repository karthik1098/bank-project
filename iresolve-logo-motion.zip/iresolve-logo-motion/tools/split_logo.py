#!/usr/bin/env python3
"""
split_logo.py - prepare the REAL iResolve logo for iResolve Logo Motion.

The animation needs the MARK on its own (red i + silver building + red swoosh, no text) as a tightly
cropped PNG with a transparent background. Use this tool when you only have:
  * the full lockup (mark + "iResolve" + chrome line + "By Credence"), or
  * a mark with lots of empty padding, or a solid white/coloured background.

Usage
  python tools/split_logo.py path/to/iresolve-logo.png                 # split a full lockup into parts
  python tools/split_logo.py path/to/iresolve-mark.png --mark-only     # just trim + make the background transparent

Options
  --out DIR          output folder (default: ./brand-out)
  --bg auto|transparent|#rrggbb
                     background handling. auto = use the alpha channel if the image has transparency,
                     otherwise detect the background colour from the image border (default: auto)
  --threshold N      colour distance treated as background for opaque images (default: 40)
  --max N            longest side of the saved mark in px (default: 1024; smaller images are kept as-is)
  --pad N            transparent padding around each saved part in px (default: 4)

Outputs (in --out)
  iresolve-mark.png        <- pass as markSrc (REQUIRED by the animation)
  iresolve-wordmark.png    <- optional wordmarkSrc ("iResolve" lettering)
  iresolve-tagline.png     <- optional taglineSrc ("By Credence")
  iresolve-line.png        <- the chrome line, if found (the animation draws its own line by default)
  iresolve-text.png        <- only if the text could not be split into lines
  split-preview.png        <- the source with a box drawn around every part: CHECK THIS
  split-report.json        <- boxes and sizes

Requires Pillow (pip install pillow). No other dependencies.
"""
import argparse
import json
import math
import os
import sys

try:
    from PIL import Image, ImageChops, ImageDraw
except ImportError:  # pragma: no cover
    sys.exit("Pillow is required: pip install pillow")


def hex_to_rgb(value):
    v = value.lstrip('#')
    if len(v) == 3:
        v = ''.join(c * 2 for c in v)
    if len(v) != 6:
        sys.exit('--bg must be auto, transparent or a colour like #ffffff')
    return tuple(int(v[i:i + 2], 16) for i in (0, 2, 4))


def has_transparency(im):
    lo, _ = im.getchannel('A').getextrema()
    return lo < 250


def border_color(im):
    rgb = im.convert('RGB')
    w, h = rgb.size
    step = max(1, min(w, h) // 60)
    px = []
    for x in range(0, w, step):
        px += [rgb.getpixel((x, 0)), rgb.getpixel((x, h - 1))]
    for y in range(0, h, step):
        px += [rgb.getpixel((0, y)), rgb.getpixel((w - 1, y))]
    px.sort(key=sum)
    return px[len(px) // 2]


def alpha_from_background(im, bg, threshold):
    """Soft alpha from the distance to the background colour (keeps anti-aliased edges)."""
    rgb = im.convert('RGB')
    diff = ImageChops.difference(rgb, Image.new('RGB', rgb.size, bg))
    r, g, b = diff.split()
    d = ImageChops.lighter(ImageChops.lighter(r, g), b)          # max channel difference
    lo, hi = threshold * 0.5, threshold * 1.5
    return d.point(lambda v: 0 if v <= lo else 255 if v >= hi else int((v - lo) * 255 / (hi - lo)))


def occupancy(mask, axis):
    w, h = mask.size
    if axis == 'x':
        return [mask.crop((x, 0, x + 1, h)).getbbox() is not None for x in range(w)]
    return [mask.crop((0, y, w, y + 1)).getbbox() is not None for y in range(h)]


def runs(occ):
    out, start = [], None
    for i, v in enumerate(occ):
        if v and start is None:
            start = i
        elif not v and start is not None:
            out.append((start, i))
            start = None
    if start is not None:
        out.append((start, len(occ)))
    return out


def widest_gap(occ):
    r = runs(occ)
    best = (0, None)
    for (_, a1), (b0, _) in zip(r, r[1:]):
        if b0 - a1 > best[0]:
            best = (b0 - a1, (a1, b0))
    return best


def tighten(mask, box):
    bb = mask.crop(box).getbbox()
    if not bb:
        return box
    return (box[0] + bb[0], box[1] + bb[1], box[0] + bb[2], box[1] + bb[3])


def union(boxes):
    return (min(b[0] for b in boxes), min(b[1] for b in boxes), max(b[2] for b in boxes), max(b[3] for b in boxes))


def squareness(box):
    w, h = box[2] - box[0], box[3] - box[1]
    return abs(math.log(w / h)) if w > 0 and h > 0 else 99


def main():
    ap = argparse.ArgumentParser(description='Prepare the iResolve logo for iResolve Logo Motion.')
    ap.add_argument('image')
    ap.add_argument('--out', default='brand-out')
    ap.add_argument('--mark-only', action='store_true')
    ap.add_argument('--bg', default='auto')
    ap.add_argument('--threshold', type=int, default=40)
    ap.add_argument('--alpha-min', type=int, default=16)
    ap.add_argument('--max', type=int, default=1024)
    ap.add_argument('--pad', type=int, default=4)
    args = ap.parse_args()

    im = Image.open(args.image)
    im.load()
    im = im.convert('RGBA')
    if max(im.size) > 3000:                                    # analyse big files at a sane size
        s = 3000 / max(im.size)
        im = im.resize((round(im.width * s), round(im.height * s)), Image.LANCZOS)

    if args.bg == 'transparent' or (args.bg == 'auto' and has_transparency(im)):
        alpha = im.getchannel('A')
        bg_used = 'transparent'
    else:
        bg = border_color(im) if args.bg == 'auto' else hex_to_rgb(args.bg)
        alpha = ImageChops.multiply(alpha_from_background(im, bg, args.threshold), im.getchannel('A'))
        bg_used = '#%02x%02x%02x' % bg

    clean = im.copy()
    clean.putalpha(alpha)
    mask = alpha.point(lambda v: 255 if v > args.alpha_min else 0)
    content = mask.getbbox()
    if not content:
        sys.exit('No logo found: the image looks empty after removing the background.')

    os.makedirs(args.out, exist_ok=True)
    report = {'source': os.path.abspath(args.image), 'background': bg_used, 'size': list(im.size), 'parts': {}}

    def save(name, box, limit=None):
        box = tighten(mask, box)
        crop = clean.crop(box)
        p = args.pad
        canvas = Image.new('RGBA', (crop.width + 2 * p, crop.height + 2 * p), (0, 0, 0, 0))
        canvas.paste(crop, (p, p))
        if limit and max(canvas.size) > limit:
            s = limit / max(canvas.size)
            canvas = canvas.resize((max(1, round(canvas.width * s)), max(1, round(canvas.height * s))), Image.LANCZOS)
        canvas.save(os.path.join(args.out, name), optimize=True)
        report['parts'][name] = {'box': list(box), 'size': list(canvas.size)}

    notes = []
    if args.mark_only:
        save('iresolve-mark.png', content, args.max)
    else:
        x0, y0, x1, y1 = content
        cm = mask.crop(content)
        cw, ch = cm.size
        gx, gxr = widest_gap(occupancy(cm, 'x'))
        gy, gyr = widest_gap(occupancy(cm, 'y'))
        rel_x = gx / cw if gxr else 0
        rel_y = gy / ch if gyr else 0
        if max(rel_x, rel_y) < 0.015:
            notes.append('No clear gap between the mark and any text: the whole image was saved as the mark.')
            save('iresolve-mark.png', content, args.max)
        else:
            if rel_x >= rel_y:                                 # mark beside the text
                a = (x0, y0, x0 + gxr[0], y1)
                b = (x0 + gxr[1], y0, x1, y1)
            else:                                              # mark above/below the text
                a = (x0, y0, x1, y0 + gyr[0])
                b = (x0, y0 + gyr[1], x1, y1)
            a, b = tighten(mask, a), tighten(mask, b)
            mark_box, text_box = (a, b) if squareness(a) <= squareness(b) else (b, a)
            save('iresolve-mark.png', mark_box, args.max)

            tm = mask.crop(text_box)
            tw, th = tm.size
            items = []
            for r0, r1 in runs(occupancy(tm, 'y')):
                bb = tm.crop((0, r0, tw, r1)).getbbox()
                if bb:
                    items.append((text_box[0] + bb[0], text_box[1] + r0 + bb[1], text_box[0] + bb[2], text_box[1] + r0 + bb[3]))
            lines = [bx for bx in items if (bx[3] - bx[1]) <= max(4, 0.06 * th) and (bx[2] - bx[0]) >= 0.4 * tw]
            others = [bx for bx in items if bx not in lines]
            if len(others) < 2 and not lines:
                notes.append('The text could not be split into lines: saved it as iresolve-text.png.')
                save('iresolve-text.png', text_box)
            else:
                word = max(others, key=lambda bx: bx[3] - bx[1])
                save('iresolve-wordmark.png', word)
                rest = [bx for bx in others if bx is not word]
                if lines:
                    save('iresolve-line.png', union(lines))
                if rest:
                    save('iresolve-tagline.png', union(rest))

    # preview with boxes
    preview = Image.new('RGBA', clean.size, (255, 255, 255, 255))
    preview.alpha_composite(clean)
    draw = ImageDraw.Draw(preview)
    colours = {'iresolve-mark.png': (210, 31, 43), 'iresolve-wordmark.png': (30, 110, 255),
               'iresolve-tagline.png': (0, 150, 80), 'iresolve-line.png': (220, 130, 0), 'iresolve-text.png': (130, 0, 200)}
    width = max(2, round(max(clean.size) / 400))
    for name, info in report['parts'].items():
        draw.rectangle(info['box'], outline=colours.get(name, (0, 0, 0)), width=width)
    preview.convert('RGB').save(os.path.join(args.out, 'split-preview.png'))
    report['notes'] = notes
    with open(os.path.join(args.out, 'split-report.json'), 'w') as f:
        json.dump(report, f, indent=2)

    print('Background: %s' % bg_used)
    for name, info in report['parts'].items():
        print('  %-24s %4d x %-4d  box=%s' % (name, info['size'][0], info['size'][1], info['box']))
    for n in notes:
        print('Note: ' + n)
    print('Check %s before using the files.' % os.path.join(args.out, 'split-preview.png'))


if __name__ == '__main__':
    main()
